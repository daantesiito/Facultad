/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practicandoparcialturnohtema1;

/**
 *
 * @author dante
 */
public class PracticandoParcialTurnoHTema1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Estadio E = new Estadio("toto","facu informatica",100);
        
        Concierto C1 = new Concierto("mayu",10,60);
        E.registarConcierto(C1,1);
        
        Concierto C2 = new Concierto("esteban",100,99);
        E.registarConcierto(C2,2);
        
        Concierto C3 = new Concierto("tucci",20,30);
        E.registarConcierto(C3,1);
        
        Concierto C4 = new Concierto("balta",60,70);
        E.registarConcierto(C4,1);
        
        String aux = E.listarConciertosMes(1);
        System.out.println(aux);
        
        System.out.println(E.gananciaMes(1));
        
        System.out.println(E.toString());
        
    }
    
}
