/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practicandoparcialturnohtema1;

/**
 *
 * @author dante
 */
public class Estadio {
    private String nombre;
    private String direccion;
    private int capacidad;
    private Concierto [][] conciertos;
    private int maxDias = 31;
    private int maxMeses = 12;
    private int [] vectorMeses;
    

    public Estadio(String nombre, String direccion, int capacidad) {
        this.nombre = nombre;
        this.direccion = direccion;
        this.capacidad = capacidad;
        conciertos = new Concierto[maxMeses][maxDias];
        vectorMeses = new int [12];
        for (int i = 0; i < 12; i++) {
            vectorMeses[i] = 0;
        }
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }

    public Concierto[][] getConciertos() {
        return conciertos;
    }

    public void setConciertos(Concierto[][] conciertos) {
        this.conciertos = conciertos;
    }

    public int getMaxDias() {
        return maxDias;
    }

    public void setMaxDias(int maxDias) {
        this.maxDias = maxDias;
    }

    public int getMaxMeses() {
        return maxMeses;
    }

    public void setMaxMeses(int maxMeses) {
        this.maxMeses = maxMeses;
    }
    
    public void registarConcierto(Concierto C, int mes) {
        if (vectorMeses[mes-1] < maxDias) {
            conciertos[mes-1][vectorMeses[mes-1]] = C;
            vectorMeses[mes-1]++;
        }
    }
    
    public String listarConciertosMes(int mes) {
        String aux = "";
        for (int i = 0; i < vectorMeses[mes-1]; i++) {
            aux += conciertos[mes-1][i].toString() + "\n";
        }   
        return aux;
    }
    
    public int gananciaMes(int mes) {
        int aux = 0;
        for (int i = 0; i < vectorMeses[mes-1]; i++) {
            aux += conciertos[mes-1][i].gananciaConcierto() * 0.5;
        }
        return aux;
    }

    @Override
    public String toString() {
        String aux = "Estadio: " + "nombre: " + nombre + ", direccion=" + direccion + ", capacidad=" + capacidad + "\n";
        for (int i = 0; i < maxMeses; i++) {
            if (vectorMeses[i] != 0) {
                aux += "Mes: " + (i+1) + "\n";
                for (int j = 0; j < vectorMeses[i]; j++) {
                    aux += "Dia: " + (j+1) + " " + conciertos[i][j].toString() + "\n";
                }
            }
        }
        return aux;
    }
    
    
}
