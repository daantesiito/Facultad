/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practicandoparcialturnohtema1;

/**
 *
 * @author dante
 */
public class Concierto {
    private String nombre;
    private int precio;
    private int cantEntradas;

    public Concierto(String nombre, int precio, int cantEntradas) {
        this.nombre = nombre;
        this.precio = precio;
        this.cantEntradas = cantEntradas;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public int getCantEntradas() {
        return cantEntradas;
    }

    public void setCantEntradas(int cantEntradas) {
        this.cantEntradas = cantEntradas;
    }
    
    public int gananciaConcierto() {
        int aux = 0;
        aux = precio * cantEntradas;
        return aux;
    }
    

    @Override
    public String toString() {
        return "Concierto: " + "Nombre del artista: " + nombre + ", precio de entrada: " + precio + ", cantidad de entradas vendidas: " + cantEntradas + "\n";
    }
}
