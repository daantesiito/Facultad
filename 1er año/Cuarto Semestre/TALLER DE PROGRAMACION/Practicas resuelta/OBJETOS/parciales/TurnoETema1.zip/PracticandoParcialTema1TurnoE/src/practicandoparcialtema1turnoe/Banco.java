/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practicandoparcialtema1turnoe;

/**
 *
 * @author dante
 */
public abstract class Banco {
    private String nombre;
    private int cantEmpleados;
    private Cuenta []  cuentas;
    private int cantCuentas;
    private int dimL = 0;
    
    public Banco() {
        
    }
    
    public Banco(String nombre,int cantEmpleados, int cuentas) {
        this.nombre = nombre;
        this.cantEmpleados = cantEmpleados;
        this.cuentas = new Cuenta[cuentas];
        this.cantCuentas = cuentas;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCantEmpleados() {
        return cantEmpleados;
    }

    public void setCantEmpleados(int cantEmpleados) {
        this.cantEmpleados = cantEmpleados;
    }

    public Cuenta[] getCuentas() {
        return cuentas;
    }

    public void setCuentas(Cuenta[] cuentas) {
        this.cuentas = cuentas;
    }

    public int getCantCuentas() {
        return cantCuentas;
    }

    public void setCantCuentas(int cantCuentas) {
        this.cantCuentas = cantCuentas;
    }  
    
    public boolean agregarCuenta(Cuenta C) {
        if (dimL < cantCuentas) {
           cuentas[dimL] = C;
           dimL++;
           return true;
        }
        return false;
        
    }
    
    public Cuenta obtenerCuenta(int unCBU) {
        Cuenta C = null;
        for (int i = 0; i < cantCuentas; i++) {
            if (cuentas[i].getCBU() == unCBU) {
                C = cuentas[i];
            }
        }
        return C;
    }
    
    public void depositarDinero(int unCBU, double unMonto) {
        Cuenta C;
        C = obtenerCuenta(unCBU);
        if (C != null) {
            C.setMonto(C.getMonto() + unMonto);
        }
    }
    
    public abstract boolean puedeRecibirTarjeta(int unCBU);
            
    
}
