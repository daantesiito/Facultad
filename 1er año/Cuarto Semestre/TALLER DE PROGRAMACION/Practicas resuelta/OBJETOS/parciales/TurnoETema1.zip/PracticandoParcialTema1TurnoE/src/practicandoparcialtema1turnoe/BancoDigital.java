/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practicandoparcialtema1turnoe;

/**
 *
 * @author dante
 */
public class BancoDigital extends Banco {
    private String direccionWeb;
    
    public BancoDigital(String dirWeb, String nombre, int cantEmpleados, int cuentas) {
        super(nombre,cantEmpleados,cuentas);
        this.direccionWeb  = dirWeb;
    }

    public String getDireccionWeb() {
        return direccionWeb;
    }

    public void setDireccionWeb(String direccionWeb) {
        this.direccionWeb = direccionWeb;
    }
    
    @Override
    public boolean agregarCuenta(Cuenta C) {
        return super.agregarCuenta(C);
    }
    
    @Override
    public boolean puedeRecibirTarjeta(int unCBU) {
        boolean aux = false;
        Cuenta C = obtenerCuenta(unCBU);
        if (C != null) {
            if (C.getMoneda().equals("Pesos") && C.getMonto() > 100000) {
                aux = true;
            }
        }
        return aux;
    }
    
}
