/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practicandoparcialtema1turnoe;

/**
 *
 * @author dante
 */
public class BancoTradicional extends Banco {
    private String direccion;
    private String localidad;
    private int cantCuentasUSD;
    
    public BancoTradicional(String direc, String loc, String nombre, int cantEmpleados, int cuentas) {
        super(nombre,cantEmpleados,cuentas);
        this.direccion = direc;
        this.localidad = loc;
        this.cantCuentasUSD = 0;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getLocalidad() {
        return localidad;
    }

    public void setLocalidad(String localidad) {
        this.localidad = localidad;
    }

    public int getCantCuentasUSD() {
        return cantCuentasUSD;
    }

    public void setCantCuentasUSD(int cantCuentasUSD) {
        this.cantCuentasUSD = cantCuentasUSD;
    }
    
    @Override
    public boolean agregarCuenta(Cuenta C) {
        if (cantCuentasUSD < 100) {
            boolean aux = super.agregarCuenta(C);
            if (aux == true) {
                if (C.getMoneda().equals("Dolar")) {
                cantCuentasUSD++;
                }
                return true;
            }
        }
        return false;
    }
    
    @Override
    public boolean puedeRecibirTarjeta(int unCBU){
        Cuenta C;
        C = obtenerCuenta(unCBU);
        if (C != null){
            if (C.getMoneda().equals("Dolar") && C.getMonto() > 500) {
                return true;
            }
            if (C.getMoneda().equals("Peso") && C.getMonto() > 70000) {
                return true;
            }
        }
        return false;
    }
}