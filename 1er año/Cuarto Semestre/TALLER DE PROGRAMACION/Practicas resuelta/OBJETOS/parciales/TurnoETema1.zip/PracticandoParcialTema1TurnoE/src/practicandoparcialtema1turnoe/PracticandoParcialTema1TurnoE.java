/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practicandoparcialtema1turnoe;

/**
 *
 * @author dante
 */
public class PracticandoParcialTema1TurnoE {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        BancoTradicional BT = new BancoTradicional("8 1425","la plata","jetskiworld",10,69);
        BancoDigital BD = new BancoDigital("jetskiworld.org","jetskiworld",20,79);
        Cuenta C;
        Cuenta C2;
        
        for (int i = 0; i < 69; i++) {
            C = new Cuenta(10,"dante",12,"Dolar");
            BT.agregarCuenta(C);
        }
        
        for (int i = 0; i < 79; i++) {
            C2 = new Cuenta(20,"dante",24,"Pesos");
            BD.agregarCuenta(C2);
        }
        
        BT.depositarDinero(10, 100000);
        BD.depositarDinero(20, 1000000);
                
        System.out.println(BT.puedeRecibirTarjeta(10));
        System.out.println(BD.puedeRecibirTarjeta(20));
    }
    
}
