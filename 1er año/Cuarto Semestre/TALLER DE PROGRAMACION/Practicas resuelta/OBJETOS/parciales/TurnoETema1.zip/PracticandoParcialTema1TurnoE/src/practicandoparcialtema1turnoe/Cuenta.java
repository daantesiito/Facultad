/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practicandoparcialtema1turnoe;

/**
 *
 * @author dante
 */
public class Cuenta {
    private int CBU;
    private String alias;
    private int DNI;
    private String moneda;
    private double monto;

    public Cuenta(int CBU, String alias, int DNI, String moneda) {
        this.CBU = CBU;
        this.alias = alias;
        this.DNI = DNI;
        this.moneda = moneda;
        this.monto = 0;
    }

    public int getCBU() {
        return CBU;
    }

    public void setCBU(int CBU) {
        this.CBU = CBU;
    }

    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    public int getDNI() {
        return DNI;
    }

    public void setDNI(int DNI) {
        this.DNI = DNI;
    }

    public String getMoneda() {
        return moneda;
    }

    public void setMoneda(String moneda) {
        this.moneda = moneda;
    }

    public double getMonto() {
        return monto;
    }

    public void setMonto(double monto) {
        this.monto = monto;
    }

    @Override
    public String toString() {
        return "Cuenta{" + "CBU=" + CBU + ", alias=" + alias + ", DNI=" + DNI + ", moneda=" + moneda + ", monto=" + monto + '}';
    }
    
    
}
