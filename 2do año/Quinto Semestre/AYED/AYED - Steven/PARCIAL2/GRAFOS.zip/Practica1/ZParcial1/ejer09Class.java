package ZParcial1;

import PackElementos.*;
import PackGrafos.*;

public class ejer09Class {
	
	private GrafoImplListAdy<String> grafo;
	
	public ejer09Class(GrafoImplListAdy<String> grafo) {
		this.grafo = grafo;
	}
	
	public ListaGenerica<String> buscarCaminoEntreOrigenYDestino(String ciudad1, String ciudad2){
		ListaGenerica<String> l = new ListaEnlazadaGenerica<String>();
		boolean[] marca = new boolean[grafo.listaDeVertices().tamanio() + 1];
		ListaGenerica<Vertice<String>> lis = grafo.listaDeVertices();
		boolean ok = false;
		boolean ok2 = false;
		int pos = 0;
		
		if (!grafo.esVacio()) {
			Vertice<String> v = null;
			lis.comenzar();
			while (!lis.fin() && !ok || !ok2) {
				v = lis.proximo();
				if (v.dato().equals(ciudad1)) {
					ok = true;
					pos = v.posicion();
				}else if (v.dato().equals(ciudad2)) {
					ok2 = true;
				}
			}
			if (ok && ok2) {
				devolver1(pos, grafo, l, marca, ciudad2);
			}
		}
		return l;
	}
	
	private boolean devolver1(int i, Grafo<String> grafo, ListaGenerica<String> l, boolean[] marca, String ciudad2) {
		boolean ok = false;
		marca[i] = true;
		
		Vertice<String> v = grafo.vertice(i);
		l.agregarFinal(v.dato());
		//System.out.println(v.dato().getNombre());
		if (v.dato().equals(ciudad2)) {
			ok =  true;
		}
		else {
			ListaGenerica<Arista<String>> ady = grafo.listaDeAdyacentes(v);
			ady.comenzar();
			while (!ady.fin() && !ok) {
				Arista<String> arista = ady.proximo();
				int j = arista.verticeDestino().posicion();
				if (!marca[j])
					ok = devolver1(j,grafo,l,marca, ciudad2);
			}
			if (!ok) {
				l.eliminarEn(l.tamanio());
				marca[i] = false; // desmarco porque puedo llegar a formar un camino desde otro vértice
			}
		}
		return ok;
	}
}