package ZParcial1;

import PackElementos.*;
import PackGrafos.*;

public class ejer05Class {
	
	public ListaGenerica<String> resolver(Grafo<Sitio> grafo){
		ListaGenerica<String> l = new ListaEnlazadaGenerica<String>();
		boolean[] marca = new boolean[grafo.listaDeVertices().tamanio() + 1];
		ListaGenerica<Vertice<Sitio>> lis = grafo.listaDeVertices();
		boolean ok = false;
		
		if (!grafo.esVacio()) {
			Vertice<Sitio> v = null;
			lis.comenzar();
			while (!lis.fin() && !ok) {
				v = lis.proximo();
				if (v.dato().getNombre().equals("Casa del Intendente")) {
					ok = true;
				}
			}
			if (ok) {
				devolver1(v.posicion(), grafo, l, marca);
			}
		}
		return l;
	}
	
	private boolean devolver1(int i, Grafo<Sitio> grafo, ListaGenerica<String> l, boolean[] marca) {
		boolean ok = false;
		marca[i] = true;
		
		Vertice<Sitio> v = grafo.vertice(i);
		l.agregarFinal(v.dato().getNombre());
		//System.out.println(v.dato().getNombre());
		if (v.dato().getNombre().equals("Municipalidad")) {
			ok = true;
		}
		else {
			ListaGenerica<Arista<Sitio>> ady = grafo.listaDeAdyacentes(v);
			ady.comenzar();
			while (!ady.fin() && !ok) {
				Arista<Sitio> arista = ady.proximo();
				int j = arista.verticeDestino().posicion();
				String estado = arista.verticeDestino().dato().getEstado();
				int estadoArista = arista.peso();
				if (!marca[j] & estado != "Control Mafia" & estadoArista != 1) {
					ok = devolver1(j,grafo,l,marca);
					if (!ok) {
						l.eliminarEn(l.tamanio());
						marca[j] = false; // desmarco porque puedo llegar a formar un camino desde otro vértice
					}
				}
			}
			
		}
		return ok;
	}
	
	
}