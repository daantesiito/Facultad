package ZParcial1;

public class Maximo {
	private int Max;

	public Maximo(int max) {
		Max = max;
	}

	public int getMax() {
		return Max;
	}

	public void setMax(int max) {
		Max = max;
	}
	

}