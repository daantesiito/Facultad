package ZParcial1;

public class Ciudad2 {
	private String nombre;
	private int transito;
	
	public Ciudad2(String nombre, int fase) {
		this.nombre = nombre;
		this.transito = fase;
	}
	
	public String getNombre() {
		return nombre;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public int getTransito() {
		return transito;
	}

	public void setTransito(int fase) {
		this.transito = fase;
	}
	

}