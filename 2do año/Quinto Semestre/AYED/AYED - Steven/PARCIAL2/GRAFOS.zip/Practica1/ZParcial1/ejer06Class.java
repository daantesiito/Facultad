package ZParcial1;

import PackElementos.*;
import PackGrafos.*;

public class ejer06Class {
	
	public ListaGenerica<ListaGenerica<String>> resolver(Grafo<String> grafo){
		ListaGenerica<String> l = new ListaEnlazadaGenerica<String>();
		ListaGenerica<ListaGenerica<String>> caminos = new ListaEnlazadaGenerica<ListaGenerica<String>>();
		boolean[] marca = new boolean[grafo.listaDeVertices().tamanio() + 1];
		int costo = 0;
		
		for (int i=1; i<=grafo.listaDeVertices().tamanio(); i++) {
			//if (!marca[i]) {
			devolver1(i, grafo, l, caminos, marca, costo);
			l.eliminarEn(l.tamanio()); // IMPORTANTE ELIMINAR EL VERTICE AL QUE ENTRO
			//}
		}
		
		return caminos;
	}
	
	private void devolver1(int i, Grafo<String> grafo, ListaGenerica<String> l, ListaGenerica<ListaGenerica<String>> caminos,
			boolean[] marca, int costo) {
		boolean ok = false;
		marca[i] = true;
		
		Vertice<String> v = grafo.vertice(i);
		l.agregarFinal(v.dato());
		if (costo == 10) {
			caminos.agregarFinal(l.clonar());
		}
		else {
			ListaGenerica<Arista<String>> ady = grafo.listaDeAdyacentes(v);
			ady.comenzar();
			while (!ady.fin() && !ok) {
				Arista<String> arista = ady.proximo();
				int j = arista.verticeDestino().posicion();
				int peso = arista.peso();
				if (!marca[j] && ((costo+peso) <= 10)) {
					devolver1(j,grafo,l,caminos, marca,(costo+peso));
					l.eliminarEn(l.tamanio());
					marca[j] = false; // desmarco porque puedo llegar a formar un camino desde otro vértice
				}
			}
		}
	}
	
	
}