package Practica4;

public class Caudal {
    private String id;
    private double valor;
    
    
    public Caudal(String id, int tardanza) {
        this.id = id;
        this.valor = tardanza;
    }

    public String getId() {
        return id;
    }

    public double getTardanza() {
        return valor;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setTardanza(double tardanza) {
        this.valor = tardanza;
    }

    
    
}