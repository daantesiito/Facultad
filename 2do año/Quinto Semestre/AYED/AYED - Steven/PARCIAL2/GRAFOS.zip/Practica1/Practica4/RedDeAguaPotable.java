package Practica4;

import PackElementos.*;

public class RedDeAguaPotable {
	
	private ArbolGeneral<String> arbol;

    public RedDeAguaPotable(ArbolGeneral<String> arbol) {
        this.arbol=arbol;
    }
	
    public double minimoCaudal (double caudal){
    	//double c = Double.MAX_VALUE;
        //c = this.calcularCaudalMinimo(arbol, caudal);
        //return c;
    	return this.calcularCaudalMinimo(arbol, caudal);
	}
    
    /*private double calcularCaudalMinimo(ArbolGeneral<String> subred, double caudal) {
    	if (!subred.tieneHijos())
			return caudal;

    	double caudalActual = caudal / subred.getHijos().tamanio();
		double caudalMinimo = Double.MAX_VALUE;;
		//System.out.println("Actual: " + caudalActual + " min: " + caudalMinimo);
		ListaGenerica<ArbolGeneral<String>> hijos = subred.getHijos();
		hijos.comenzar();
		while (!hijos.fin())
			caudalMinimo = Math.min(caudalMinimo, calcularCaudalMinimo(hijos.proximo(), caudalActual));
		
		return caudalMinimo;
    }*/
    
    private double calcularCaudalMinimo (ArbolGeneral<String> a,  double caudal) {
    	double min = caudal;
		if (a.tieneHijos()) {
			ListaGenerica<ArbolGeneral<String>> hijos = a.getHijos();
		    double actual = caudal / hijos.tamanio();
		    hijos.comenzar();
		    while (!hijos.fin()) {
		    	min =  Math.min(min, calcularCaudalMinimo(hijos.proximo(), actual));
		    }
		}
		return min;
	}
}