package Practica4;

import PackElementos.*;

public class PracticaProfundidad {
    public static void main(String[] args) {
        //           14
        //         /    \
        //        53     2
        //       / \    / \
        //      12  9  33 102
        ArbolGeneral<Integer> num14 =new ArbolGeneral(14);
        ArbolGeneral<Integer> num53 =new ArbolGeneral(53);
        ArbolGeneral<Integer> num2 =new ArbolGeneral(2);
        ArbolGeneral<Integer> num12 =new ArbolGeneral(12);
        ArbolGeneral<Integer> num9 = new ArbolGeneral(9);
        ArbolGeneral<Integer> num33 =new ArbolGeneral(33);
        ArbolGeneral<Integer> num102 =new ArbolGeneral(102);

        num14.agregarHijo(num53);
        num14.agregarHijo(num2);
        num53.agregarHijo(num12);
        num53.agregarHijo(num9);
        num2.agregarHijo(num33);
        num2.agregarHijo(num102);

        ProfundidadArbolGeneral prof = new ProfundidadArbolGeneral(num14);
        System.out.println("La suma del nivel 0 es: "+prof.sumaElementosProfundidad(0));
        System.out.println("La suma del nivel 1 es: "+prof.sumaElementosProfundidad(1));
        System.out.println("La suma del nivel 2 es: "+prof.sumaElementosProfundidad(2));
        System.out.println("La suma del nivel 3 es: "+prof.sumaElementosProfundidad(3)); //no existe nivel 3 -> -1
        System.out.println("La suma del nivel 3 es: "+prof.sumaElementosProfundidad(-5));
    
        System.out.println();
        
        int nivelNoRep = 2;
        ListaGenerica<Integer> listaNoRep = prof.listaNoRepetidosNivel(nivelNoRep);
        System.out.println("Lista de elementos no repetidos del nivel " + nivelNoRep);
        listaNoRep.comenzar();
        while (!listaNoRep.fin()) {
        	System.out.println(listaNoRep.proximo());
        }
    
    }
}