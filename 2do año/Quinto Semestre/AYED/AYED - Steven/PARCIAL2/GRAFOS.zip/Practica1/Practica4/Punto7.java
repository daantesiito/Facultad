package Practica4;
import PackElementos.*;

public class Punto7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    	//      	             A1000
	    //          /     /             \            \
	    //      B250    C250              D250         E250
	    //             /    \          /  /   \  \     \
	    //           F125  G125     H50 I50  J50  K50  O50
		//                   |               /  \
		//                 L125            M25  N25
    	
    	
	    ArbolGeneral<String> padre = new ArbolGeneral<String>("A");
	    
	    ArbolGeneral<String> hijo1 = new ArbolGeneral<String>("B");
	    ArbolGeneral<String> hijo2 = new ArbolGeneral<String>("C");
	    ArbolGeneral<String> hijo3 = new ArbolGeneral<String>("D");
	    ArbolGeneral<String> hijo4 = new ArbolGeneral<String>("E");
	    
	    ArbolGeneral<String> subhijo1 = new ArbolGeneral<String>("F");
	    ArbolGeneral<String> subhijo2 = new ArbolGeneral<String>("G");
	    ArbolGeneral<String> subhijo3 = new ArbolGeneral<String>("H");
	    ArbolGeneral<String> subhijo4 = new ArbolGeneral<String>("I");
	    ArbolGeneral<String> subhijo5 = new ArbolGeneral<String>("J");
	    ArbolGeneral<String> subhijo6 = new ArbolGeneral<String>("K");
	    ArbolGeneral<String> subhijo7 = new ArbolGeneral<String>("L");
	    ArbolGeneral<String> subhijo8 = new ArbolGeneral<String>("M");
	    ArbolGeneral<String> subhijo9 = new ArbolGeneral<String>("N");
	    
	    ArbolGeneral<String> subhijo10 = new ArbolGeneral<String>("O");
        
	    padre.agregarHijo(hijo1);
	    padre.agregarHijo(hijo2);
	    padre.agregarHijo(hijo3);
	    padre.agregarHijo(hijo4);
	    
	    
	    hijo2.agregarHijo(subhijo1);
	    hijo2.agregarHijo(subhijo2);
	    subhijo2.agregarHijo(subhijo7);
	    
	    hijo3.agregarHijo(subhijo3);
	    hijo3.agregarHijo(subhijo4);
	    hijo3.agregarHijo(subhijo5);
	    hijo3.agregarHijo(subhijo6);
	    hijo3.agregarHijo(subhijo10);
	    subhijo5.agregarHijo(subhijo8);
	    subhijo5.agregarHijo(subhijo9);
	    
	    //System.out.println("ARBOL GENERAL CON UNA ALTURA DE: " + padre.altura());
	    //padre.printPorNiveles();
	    
	    RedDeAguaPotable red = new RedDeAguaPotable(padre);
	    
	    double caudal = 1000;
	    double min = red.minimoCaudal(caudal);
	    
	    
	    System.out.println("El minimo caudal que recibe su casa es de " + min);
	    
	    
	    
    }
    
}
