package Practica4;
import PackElementos.*;

public class Punto5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    	//      	       M14
	    //          /        |         \
	    //      J13         K25         L10
	    //    /  |  \     /  |  \     /  |  \
	    //   A4 B7  C5   D6 E10 F18  G9 H12 I19
    	AreaEmpresa ar14 = new AreaEmpresa("M", 14);
	    ArbolGeneral<AreaEmpresa> m14 = new ArbolGeneral<AreaEmpresa>(ar14);
	    
	    AreaEmpresa ar13 = new AreaEmpresa("J", 13);
	    ArbolGeneral<AreaEmpresa> j13 = new ArbolGeneral<AreaEmpresa>(ar13);
	    AreaEmpresa ar4 = new AreaEmpresa("A", 4);
	    ArbolGeneral<AreaEmpresa> a4 = new ArbolGeneral<AreaEmpresa>(ar4);
	    AreaEmpresa ar7 = new AreaEmpresa("B", 7);
	    ArbolGeneral<AreaEmpresa> b7 = new ArbolGeneral<AreaEmpresa>(ar7);
	    AreaEmpresa ar5 = new AreaEmpresa("C", 5);
	    ArbolGeneral<AreaEmpresa> c5 = new ArbolGeneral<AreaEmpresa>(ar5);
	    
	    
	    AreaEmpresa ar25 = new AreaEmpresa("K", 25);
	    ArbolGeneral<AreaEmpresa> k25 = new ArbolGeneral<AreaEmpresa>(ar25);
	    AreaEmpresa ar6 = new AreaEmpresa("D", 6);
	    ArbolGeneral<AreaEmpresa> d6 = new ArbolGeneral<AreaEmpresa>(ar6);
	    AreaEmpresa ar10 = new AreaEmpresa("E", 10);
	    ArbolGeneral<AreaEmpresa> e10 = new ArbolGeneral<AreaEmpresa>(ar10);
	    AreaEmpresa ar18 = new AreaEmpresa("F", 18);
	    ArbolGeneral<AreaEmpresa> f18 = new ArbolGeneral<AreaEmpresa>(ar18);
	    
	    
	    AreaEmpresa ar10v2 = new AreaEmpresa("L", 10);
	    ArbolGeneral<AreaEmpresa> l10 = new ArbolGeneral<AreaEmpresa>(ar10v2);
	    AreaEmpresa ar9 = new AreaEmpresa("G", 9);
	    ArbolGeneral<AreaEmpresa> g9 = new ArbolGeneral<AreaEmpresa>(ar9);
	    AreaEmpresa ar12 = new AreaEmpresa("H", 12);
	    ArbolGeneral<AreaEmpresa> h12 = new ArbolGeneral<AreaEmpresa>(ar12);
	    AreaEmpresa ar19 = new AreaEmpresa("I", 19);    /// PONER EN 19                         /////////////////////////
	    ArbolGeneral<AreaEmpresa> i19 = new ArbolGeneral<AreaEmpresa>(ar19);
	    
	    
        
	    m14.agregarHijo(j13);
	    m14.agregarHijo(k25);
	    m14.agregarHijo(l10);
	    
	    j13.agregarHijo(a4);
	    j13.agregarHijo(b7);
	    j13.agregarHijo(c5);
	    
	    k25.agregarHijo(d6);
	    k25.agregarHijo(e10);
	    k25.agregarHijo(f18);
	    
	    l10.agregarHijo(g9);
	    l10.agregarHijo(h12);
	    l10.agregarHijo(i19);
	    
	    
	    System.out.println("ARBOL GENERAL CON UNA ALTURA DE: " + m14.altura());
	    
	    
	    AnalizadorArbol analizador = new AnalizadorArbol(m14);
	    
	    int mayorPromedio = analizador.devolverMaximoPromedio();

	    System.out.println("El nivel con el mayor promedio tiene un promedio de " + mayorPromedio);
	    
	    
	    
    }
    
}
