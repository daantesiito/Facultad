package Practica3V2;
import PackElementos.*;

public class Punto3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    	//      	14
	    //         /  \
	    //        53   2
	    //       /    / \
	    //      12   33 102
	    ArbolBinario<Integer> a14 = new ArbolBinario<Integer>(14);
	    ArbolBinario<Integer> a53 = new ArbolBinario<Integer>(53);
	    ArbolBinario<Integer> a12 = new ArbolBinario<Integer>(12);
	    ArbolBinario<Integer> a2 = new ArbolBinario<Integer>(2);
	    ArbolBinario<Integer> a33 = new ArbolBinario<Integer>(33);
	    ArbolBinario<Integer> a102 = new ArbolBinario<Integer>(102);
        
	    a14.agregarHijoIzquierdo(a53);
	    a53.agregarHijoIzquierdo(a12);
	    a14.agregarHijoDerecho(a2);
	    a2.agregarHijoIzquierdo(a33);
	    a2.agregarHijoDerecho(a102);
	    
	    //a14.printInorden();
	    
	    
	    System.out.println("LISTA IN ORDEN: ");
	    ContadorArbol cont = new ContadorArbol();
	    ListaEnlazadaGenerica<Integer> listaInOrden = cont.numerosParesInOrden(a14);
	    listaInOrden.comenzar();
	    while (!listaInOrden.fin()) {
	    	System.out.println(listaInOrden.proximo());
	    }
	    
	    
	    System.out.println("LISTA POST ORDEN: ");
	    ListaEnlazadaGenerica<Integer> listaPostOrden = cont.numerosParesPostOrden(a14);
	    listaPostOrden.comenzar();
	    while (!listaPostOrden.fin()) {
	    	System.out.println(listaPostOrden.proximo());
	    }
    }
    
}
