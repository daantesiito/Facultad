/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Practica3V2;

import PackElementos.*;

public class ContadorArbol {

    private ListaEnlazadaGenerica<Integer> paresInOrden(ArbolBinario<Integer> arbol, ListaEnlazadaGenerica<Integer> lista) {
    	if (arbol.tieneHijoIzquierdo()) {
    		paresInOrden(arbol.getHijoIzquierdo(), lista);
    	}
    	
    	if (arbol.getDato() % 2 == 0) {
    		lista.agregarFinal(arbol.getDato());
    	}
    	
    	if (arbol.tieneHijoDerecho()) {
    		paresInOrden(arbol.getHijoDerecho(), lista);
    	}
    	
    	return lista;
    }
    
    public ListaEnlazadaGenerica<Integer> numerosParesInOrden(ArbolBinario<Integer> arbol) {
    	ListaEnlazadaGenerica<Integer> lista = new ListaEnlazadaGenerica<Integer>();
    	paresInOrden(arbol, lista);
    	return lista;
    }
    
    
    
    
    private ListaEnlazadaGenerica<Integer> paresPostOrden(ArbolBinario<Integer> arbol, ListaEnlazadaGenerica<Integer> lista) {
    	if (arbol.tieneHijoIzquierdo()) {
    		paresPostOrden(arbol.getHijoIzquierdo(), lista);
    	}
    	
    	if (arbol.tieneHijoDerecho()) {
    		paresPostOrden(arbol.getHijoDerecho(), lista);
    	}
    	
    	if (arbol.getDato() % 2 == 0) {
    		lista.agregarFinal(arbol.getDato());
    	}
    	
    	return lista;
    }
    
    public ListaEnlazadaGenerica<Integer> numerosParesPostOrden(ArbolBinario<Integer> arbol) {
    	ListaEnlazadaGenerica<Integer> lista = new ListaEnlazadaGenerica<Integer>();
    	paresPostOrden(arbol, lista);
    	return lista;
    }
    
}
