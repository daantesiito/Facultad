/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PackElementos;
//import Generica.*;
/**
 *
 * @author Esteban
 */
public class PilaGenerica<T> {
    
    private ListaGenerica<T> datos = new ListaEnlazadaGenerica<T>();

    public void apilar(T elem){
        datos.agregarFinal(elem);    
    }
    public T desapilar(){
        if (!esVacia()){
            T elemento = this.tope();
            datos.eliminarEn(1);
            return elemento;
        }else{
            return null;
        }
    }
    public T tope(){
        return datos.elemento(1);
    }
    public boolean esVacia(){
        return datos.esVacia();
    }
    
}
