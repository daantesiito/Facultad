package ZParcialProfe;

import PackElementos.*;
import PackGrafos.*;

public class tema2Class {
	
	public ListaGenerica<ListaGenerica<String>> resolver(Grafo<Estadio> grafo, String ciudad1, int cantKm){
		
		ListaGenerica<ListaGenerica<String>> caminos = new ListaEnlazadaGenerica<ListaGenerica<String>>();
		
		if (!grafo.esVacio()) {
			ListaGenerica<String> actual = new ListaEnlazadaGenerica<String>();
			boolean[] marca = new boolean[grafo.listaDeVertices().tamanio() + 1];
			ListaGenerica<Vertice<Estadio>> lis = grafo.listaDeVertices();
			boolean ok = false;
			Vertice<Estadio> v = null;
			lis.comenzar();
			while (!lis.fin() && !ok) {
				v = lis.proximo();
				if (v.dato().getNombre().equals(ciudad1)) {
					ok = true;
				}
			}
			if (ok) {
				devolver(v.posicion(), grafo, actual, caminos, marca, cantKm);
			}
		}
		
		return caminos;
	}

	private void devolver(int i, Grafo<Estadio> grafo, ListaGenerica<String> l, ListaGenerica<ListaGenerica<String>> caminos,
			boolean[] marca, int cantKm) {
		
		marca[i] = true;
		
		Vertice<Estadio> v = grafo.vertice(i);
		l.agregarFinal(v.dato().getNombre());
		
		ListaGenerica<Arista<Estadio>> ady = grafo.listaDeAdyacentes(v);
		ady.comenzar();
		while (!ady.fin()) {
			Arista<Estadio> arista = ady.proximo();
			int j = arista.verticeDestino().posicion();
			if (!marca[j]) {
				if ((cantKm-arista.peso())>=0){
					devolver(j,grafo,l, caminos, marca, (cantKm-arista.peso()));
					l.eliminarEn(l.tamanio());
					marca[j] = false; // desmarco porque puedo llegar a formar un camino desde otro vértice
				}else {
					caminos.agregarFinal(l.clonar());
				}
				//System.out.println("DEST: " + arista.verticeDestino().dato().getCiudad() + " y cantkm act: " + cantKm);
			}
		}
	}
	
	
}