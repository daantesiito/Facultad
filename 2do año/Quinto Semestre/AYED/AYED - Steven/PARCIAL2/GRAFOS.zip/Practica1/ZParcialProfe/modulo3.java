package ZParcialProfe;

import PackElementos.*;
import PackGrafos.*;

public class modulo3 {

	public static void main(String[] args) {
	/*1*/	Vertice<String> municipalidad = new VerticeImplListAdy<String>("Municipalidad");
	/*2*/	Vertice<String> esq1 = new VerticeImplListAdy<String>("esq1");
	/*3*/	Vertice<String> esq2 = new VerticeImplListAdy<String>("esq2");
	/*4*/	Vertice<String> esq3 = new VerticeImplListAdy<String>("esq3");
	/*5*/	Vertice<String> esq4 = new VerticeImplListAdy<String>("esq4");
	/*6*/	Vertice<String> esq5 = new VerticeImplListAdy<String>("esq5");
	/*7*/	Vertice<String> esq6 = new VerticeImplListAdy<String>("esq6");
	/*8*/	Vertice<String> esq7 = new VerticeImplListAdy<String>("esq7");
	/*9*/	Vertice<String> esq8 = new VerticeImplListAdy<String>("esq8");
	/*10*/	Vertice<String> esq9 = new VerticeImplListAdy<String>("esq9");
	/*11*/	Vertice<String> esq10 = new VerticeImplListAdy<String>("esq10");
		
		Grafo<String> ciudad = new GrafoImplListAdy<String>();
		
		ciudad.agregarVertice(municipalidad);
		ciudad.agregarVertice(esq1);
		ciudad.agregarVertice(esq2);
		ciudad.agregarVertice(esq3);
		ciudad.agregarVertice(esq4);
		ciudad.agregarVertice(esq5);
		ciudad.agregarVertice(esq6);
		ciudad.agregarVertice(esq7);
		ciudad.agregarVertice(esq8);
		ciudad.agregarVertice(esq9);
		ciudad.agregarVertice(esq10);
		
		ciudad.conectar(municipalidad, esq1, 90);
		ciudad.conectar(esq1,municipalidad, 90);
		ciudad.conectar(municipalidad,esq10, 95);
		ciudad.conectar(esq10,municipalidad, 95);
		ciudad.conectar(municipalidad,esq4, 90);
		ciudad.conectar(esq4,municipalidad, 90);
		ciudad.conectar(esq1,esq2, 70);
		ciudad.conectar(esq2,esq1, 70);
		ciudad.conectar(esq1,esq3, 80);
		ciudad.conectar(esq3,esq1, 80);
		ciudad.conectar(esq3,esq10, 85);
		ciudad.conectar(esq10,esq3, 85);
		ciudad.conectar(esq10,esq5, 100);
		ciudad.conectar(esq5,esq10, 100);
		ciudad.conectar(esq10,esq4, 90);
		ciudad.conectar(esq4,esq10, 90);
		ciudad.conectar(esq5,esq9, 100);
		ciudad.conectar(esq9,esq5, 100);
		ciudad.conectar(esq4,esq6, 70);
		ciudad.conectar(esq6,esq4, 70);
		ciudad.conectar(esq4,esq8, 60);
		ciudad.conectar(esq8,esq4, 60);
		ciudad.conectar(esq9,esq8, 80);
		ciudad.conectar(esq8,esq9, 80);
		
		ciudad.conectar(esq8,esq7, 50);
		ciudad.conectar(esq7,esq8, 50);
		
		ciudad.conectar(esq7,esq6, 110);
		ciudad.conectar(esq6,esq7, 110);
		
		
		modulo3Class parcial = new modulo3Class();
		
		ListaGenerica<String> lugaresRestringidos = new ListaEnlazadaGenerica<String>();
		lugaresRestringidos.agregarFinal("esq5");
		lugaresRestringidos.agregarFinal("esq7");
		int metrosMax = 420;
		
		ListaGenerica<String> lis = parcial.resolver(ciudad,metrosMax,lugaresRestringidos);
		lis.comenzar();
		while(!lis.fin()) {
			System.out.println(lis.proximo());
		}
		
	}

}