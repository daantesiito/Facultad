package ZParcialProfe;

import PackElementos.*;
import PackGrafos.*;

public class recuperatorioClass {
	
	public ListaGenerica<String> resolver(Grafo<String> lugares, String ciudad1, 
			String ciudad2, int pagoMax){
		
		ListaGenerica<String> l = new ListaEnlazadaGenerica<String>();
		boolean[] marca = new boolean[lugares.listaDeVertices().tamanio() + 1];
		ListaGenerica<Vertice<String>> lis = lugares.listaDeVertices();
		boolean ok = false;
		
		if (!lugares.esVacio()) {
			Vertice<String> v = null;
			lis.comenzar();
			while (!lis.fin() && !ok) {
				v = lis.proximo();
				if (v.dato().equals(ciudad1)) {
					ok = true;
				}
			}
			if (ok) {
				devolver(v.posicion(), lugares, l, ciudad2, marca, pagoMax);
			}
		}
		
		return l;
	}

	private boolean devolver(int i, Grafo<String> grafo, ListaGenerica<String> l,
			String ciudad2, boolean[] marca, int pagoMax) {
		boolean ok = false;
		marca[i] = true;
		
		Vertice<String> v = grafo.vertice(i);
		l.agregarFinal(v.dato());
		//System.out.println("ACT: "+ v.dato());

		if (v.dato().equals(ciudad2)) {
			ok = true;
			System.out.println("EL RECORRIDO SE TERMINO CON $"+(pagoMax));
		}else {
			ListaGenerica<Arista<String>> ady = grafo.listaDeAdyacentes(v);
			ady.comenzar();
			while (!ady.fin() && !ok) {
				Arista<String> arista = ady.proximo();
				int j = arista.verticeDestino().posicion();
				if (!marca[j] && ((pagoMax-arista.peso())>=0)) {
					//System.out.println(pagoMax-arista.peso()+ " dato -> " +grafo.vertice(j).dato());
					ok = devolver(j,grafo,l, ciudad2, marca, (pagoMax-arista.peso()));
				}
			}
			if (!ok) {
				l.eliminarEn(l.tamanio());
				marca[i] = false; // desmarco porque puedo llegar a formar un camino desde otro vértice
			}
		}
		return ok;
	}
	
	
}