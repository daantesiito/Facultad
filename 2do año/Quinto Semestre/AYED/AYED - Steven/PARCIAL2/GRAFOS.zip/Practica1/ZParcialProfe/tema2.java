package ZParcialProfe;

import PackElementos.*;
import PackGrafos.*;

public class tema2 {

	public static void main(String[] args) {
		Estadio jor = new Estadio("AL BAYT STADIUM", "Jor");
	/*1*/	Vertice<Estadio> v1 = new VerticeImplListAdy<Estadio>(jor);
	
		Estadio lus = new Estadio("LUSAIL STADIUM", "Lusail");
	/*2*/	Vertice<Estadio> v2 = new VerticeImplListAdy<Estadio>(lus);
	
		Estadio edu = new Estadio("EDUCATION CITY STADIUM", "Rayan");
	/*3*/	Vertice<Estadio> v3 = new VerticeImplListAdy<Estadio>(edu);
	
		Estadio alr = new Estadio("AL RAYYAN STADIUM", "Rayan");
	/*4*/	Vertice<Estadio> v4 = new VerticeImplListAdy<Estadio>(alr);
	
		Estadio doh = new Estadio("KHALIFA INTERNATIONAL STADIUM", "Doha");
	/*5*/	Vertice<Estadio> v5 = new VerticeImplListAdy<Estadio>(doh);
	
		Estadio doh2 = new Estadio("AL THUMAMA STADIUM", "Doha");
	/*6*/	Vertice<Estadio> v6 = new VerticeImplListAdy<Estadio>(doh2);
		
		Estadio wak = new Estadio("AL JANOUB STADIUM", "Wakrah");
	/*7*/	Vertice<Estadio> v7 = new VerticeImplListAdy<Estadio>(wak);
	
		Estadio doh3 = new Estadio("STADIUM 947", "Doha");
	/*8*/	Vertice<Estadio> v8 = new VerticeImplListAdy<Estadio>(doh3);
	
		Grafo<Estadio> ciudad = new GrafoImplListAdy<Estadio>();
		
		ciudad.agregarVertice(v1);
		ciudad.agregarVertice(v2);
		ciudad.agregarVertice(v3);
		ciudad.agregarVertice(v4);
		ciudad.agregarVertice(v5);
		ciudad.agregarVertice(v6);
		ciudad.agregarVertice(v7);
		ciudad.agregarVertice(v8);
		
		ciudad.conectar(v1, v2, 42);
		ciudad.conectar(v2,v1, 42);
		
		ciudad.conectar(v2,v8, 52);
		ciudad.conectar(v8,v2, 52);
		
		ciudad.conectar(v2,v3, 24);
		ciudad.conectar(v3,v2, 24);
		
		ciudad.conectar(v3,v4, 11);
		ciudad.conectar(v4,v3, 11);
		
		ciudad.conectar(v4,v5, 8);
		ciudad.conectar(v5,v4, 8);
		
		ciudad.conectar(v5,v6, 12);
		ciudad.conectar(v6,v5, 12);
		
		ciudad.conectar(v6,v7, 12);
		ciudad.conectar(v7,v6, 12);
		
		ciudad.conectar(v8,v7, 19);
		ciudad.conectar(v7,v8, 19);
		
		
		tema2Class parcial = new tema2Class();
		
		int cantKm = 100;
		
		ListaGenerica<ListaGenerica<String>> lis = parcial.resolver(ciudad,"AL BAYT STADIUM", cantKm);
		lis.comenzar();
		while(!lis.fin()) {
			System.out.println(lis.proximo());
		}
		
	}

}