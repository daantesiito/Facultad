package PackGrafos;

import PackElementos.*;
//import PackGrafos.*;

public class RecorridosMejor {
	
	public ListaGenerica<String> dfs (Grafo<String> grafo){
		ListaGenerica<String> l = new ListaEnlazadaGenerica<String>();
		
		if (!grafo.esVacio()) {
			boolean[] marca = new boolean[grafo.listaDeVertices().tamanio() + 1];
			ListaGenerica<Vertice<String>> lis = grafo.listaDeVertices();
			boolean ok = false;
			Vertice<String> v = null;
			lis.comenzar();
			while (!lis.fin() && !ok) {
				v = lis.proximo();
				if (v.dato().equals("origen")) { //&& !marca[v.posicion()] por si piden verificar que se puede pasar por el origen (no está en la lista de exceptuando)
					ok = true;
				}
			}
			if (ok) {
				dfsPrivado(v.posicion(), grafo, l, marca, "destino");
			}
		}
		
		/* EN CASO DE GRAFO NO CONEXO
		for (int i=1; i<=grafo.listaDeVertices().tamanio(); i++) {
			if (!marca[i])
				this.dfs(i,grafo,lis,marca);
		}
		*/
		return l;
	}
	
	private boolean dfsPrivado (int i,Grafo<String> grafo,ListaGenerica<String> l, 
			boolean[] marca, String destino) {
		boolean ok = false;
		marca[i] = true;
		
		Vertice<String> v = grafo.vertice(i);
		l.agregarFinal(v.dato());
		if (v.dato().equals(destino)) {
			ok = true;
		}
		else {
			ListaGenerica<Arista<String>> ady = grafo.listaDeAdyacentes(v);
			ady.comenzar();
			while (!ady.fin() && !ok) {
				Arista<String> arista = ady.proximo();
				int j = arista.verticeDestino().posicion();
				if (!marca[j])
					ok = dfsPrivado(j,grafo,l,marca, destino);
			}
			if (!ok) {
				l.eliminarEn(l.tamanio());
				marca[i] = false; // desmarco porque puedo llegar a formar un camino desde otro vértice
			}
		}
		return ok;
		
	}
	
	
	public ListaGenerica<String> bfs (Grafo<String> grafo){
		boolean[]marca = new boolean[grafo.listaDeVertices().tamanio() + 1];
		ListaGenerica<String> lis = new ListaEnlazadaGenerica<String>();
		for (int i=1; i<=grafo.listaDeVertices().tamanio(); i++) {
			if (!marca[i])
				bfsPrivado(i,grafo,lis,marca);
		}
		return lis;
	}
	
	private void bfsPrivado (int i,Grafo<String> grafo,ListaGenerica<String> lis, boolean[] marca) {
		ColaGenerica<Vertice<String>> cola = new ColaGenerica<Vertice<String>>();
		cola.encolar(grafo.vertice(i));
		cola.encolar(null);
		marca[i]= true;
		int nivel = 0;
		
		while(!cola.esVacia()) {
			Vertice <String> v = cola.desencolar();
			if (v != null) {
				//lis.agregarFinal(v.dato());
				ListaGenerica<Arista<String>> ady = grafo.listaDeAdyacentes(v);
				ady.comenzar();
				while(!ady.fin()) {
					Arista<String> arista = ady.proximo();
					int j = arista.verticeDestino().posicion();
					if (!marca[j]) {
						cola.encolar(arista.verticeDestino());
						marca[j] = true;
					}
				}
			}else {
				if (!cola.esVacia()) {
					cola.encolar(null);
					nivel++;
				}
			}
		}
		
	}
	
	
	private boolean[] marcarExceptuando(Grafo<String> grafo, ListaGenerica<String> exceptuando) {
		boolean[] devolver = new boolean[grafo.listaDeVertices().tamanio() + 1];
			
		if (!grafo.esVacio()) {
			Vertice<String> v = null;
			exceptuando.comenzar();
			while (!exceptuando.fin()) {
				boolean ok = false;
				String act = exceptuando.proximo();
				ListaGenerica<Vertice<String>> lis = grafo.listaDeVertices();
				lis.comenzar();
				while (!lis.fin() && !ok) {
					v = lis.proximo();
					if (v.dato().equals(act)) {
						ok = true;
						devolver[v.posicion()] = true; //LO MARCO COMO VISITADO ASI NO ENTRO EN ESE VERTICE
					}
				}
			}
		}
		return devolver;
	}
	
	
}