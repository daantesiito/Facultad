package Practica6V2;

import PackElementos.*;
import PackGrafos.*;

public class Mapa{
	
	private Grafo<String> grafo;
	
	public Mapa(Grafo<String> grafo) {
		this.grafo = grafo;
	}
	
	public ListaGenerica<String> devolverCamino(String ciudad1, String ciudad2){
		ListaGenerica<String> l = new ListaEnlazadaGenerica<String>();
		boolean[] marca = new boolean[grafo.listaDeVertices().tamanio() + 1];
		ListaGenerica<Vertice<String>> lis = grafo.listaDeVertices();
		boolean ok = false;
		
		if (!grafo.esVacio()) {
			Vertice<String> v = null;
			lis.comenzar();
			while (!lis.fin() && !ok) {
				v = lis.proximo();
				if (v.dato().equals(ciudad1)) {
					ok = true;
				}
			}
			if (ok) {
				devolver1(v.posicion(), grafo, l, marca, ciudad2);
			}
		}
		return l;
	}
	
	private boolean devolver1(int i, Grafo<String> grafo, ListaGenerica<String> l, boolean[] marca, String ciudad2) {
		boolean ok = false;
		marca[i] = true;
		
		Vertice<String> v = grafo.vertice(i);
		l.agregarFinal(v.dato());
		if (v.dato().equals(ciudad2)) {
			ok =  true;
		}
		else {
			ListaGenerica<Arista<String>> ady = grafo.listaDeAdyacentes(v);
			ady.comenzar();
			while (!ady.fin() && !ok) {
				Arista<String> arista = ady.proximo();
				int j = arista.verticeDestino().posicion();
				if (!marca[j])
					ok = devolver1(j,grafo,l,marca, ciudad2);
			}
			if (!ok) {
				l.eliminarEn(l.tamanio());
				marca[i] = false; // desmarco porque puedo llegar a formar un camino desde otro vértice
			}
		}
		return ok;
	}
	
	
	//----------------------------------------------------------------------------------------------------
	//----------------------------------------------------------------------------------------------------
	
	
	private boolean[] marcarExceptuando(Grafo<String> grafo, ListaGenerica<String> exceptuando) {
		boolean[] devolver = new boolean[grafo.listaDeVertices().tamanio() + 1];
			
		if (!grafo.esVacio()) {
			Vertice<String> v = null;
			exceptuando.comenzar();
			while (!exceptuando.fin()) {
				boolean ok = false;
				String act = exceptuando.proximo();
				//System.out.println("EXCP:" + act);
				ListaGenerica<Vertice<String>> lis = grafo.listaDeVertices();
				lis.comenzar();
				while (!lis.fin() && !ok) {
					v = lis.proximo();
					if (v.dato().equals(act)) {
						//System.out.println("encontre:" + v.dato());
						ok = true;
						devolver[v.posicion()] = true; //LO MARCO COMO VISITADO ASI NO ENTRO EN ESE VERTICE
					}
				}
			}
		}
		return devolver;
	}
	
	/*
	for (int i = 1; i<marca.length; i++) {
		System.out.println(marca[i]);
	}
	 */
	
	public ListaGenerica<String> devolverCaminoExceptuando(String ciudad1, String ciudad2, ListaGenerica<String> exceptuando){
		ListaGenerica<String> l = new ListaEnlazadaGenerica<String>();
		//boolean[] marca = new boolean[grafo.listaDeVertices().tamanio() + 1];
		boolean[] marca = marcarExceptuando(grafo, exceptuando); //RECORRIDO MARCANDO LOS QUE NO TENGO QUE ENTRAR EN VERDADERO
		ListaGenerica<Vertice<String>> lis = grafo.listaDeVertices();
		boolean ok = false;
		
		
		if (!grafo.esVacio()) {
			Vertice<String> v = null;
			lis.comenzar();
			while (!lis.fin() && !ok) {
				v = lis.proximo();
				if (v.dato().equals(ciudad1) && !marca[v.posicion()]) {
					ok = true;
				}
			}
			if (ok) {
				devolver2(v.posicion(), grafo, l, marca, ciudad2);
			}
		}
		return l;
	}
	
	private boolean devolver2(int i, Grafo<String> grafo, ListaGenerica<String> l, boolean[] marca, String ciudad2) {
		boolean ok = false;
		marca[i] = true;
		
		Vertice<String> v = grafo.vertice(i);
		l.agregarFinal(v.dato());
		if (v.dato().equals(ciudad2)) {
			ok =  true;
		}
		else {
			ListaGenerica<Arista<String>> ady = grafo.listaDeAdyacentes(v);
			ady.comenzar();
			while (!ady.fin() && !ok) {
				Arista<String> arista = ady.proximo();
				int j = arista.verticeDestino().posicion();
				if (!marca[j]) {
					ok = devolver2(j,grafo,l,marca, ciudad2);
				}
			}
			if (!ok) {
				l.eliminarEn(l.tamanio());
				marca[i] = false; // desmarco porque puedo llegar a formar un camino desde otro vértice
			}
		}
		return ok;
	}
	
	
	//----------------------------------------------------------------------------------------------------
	//----------------------------------------------------------------------------------------------------
	
	private void reemplazar(ListaGenerica<String> actual, ListaGenerica<String> l) {
		l.comenzar();
		while (!l.fin()) {
			l.eliminar(l.proximo());
		}
		actual.comenzar();
		while (!actual.fin()) {
			l.agregarFinal(actual.proximo());
		}
	}
	
	
	public ListaGenerica<String> caminoMasCorto(String ciudad1, String ciudad2){
		ListaGenerica<String> actual = new ListaEnlazadaGenerica<String>();
		ListaGenerica<String> l = new ListaEnlazadaGenerica<String>();
		boolean[] marca = new boolean[grafo.listaDeVertices().tamanio() + 1];
		ListaGenerica<Vertice<String>> lis = grafo.listaDeVertices();
		boolean ok = false;
		
		if (!grafo.esVacio()) {
			Vertice<String> v = null;
			lis.comenzar();
			while (!lis.fin() && !ok) {
				v = lis.proximo();
				if (v.dato().equals(ciudad1)) {
					ok = true;
				}
			}
			if (ok) {
				Min minimo = new Min(9999);
				int distancia = 0;
				devolver3(v.posicion(), grafo, actual, l, marca, ciudad2, distancia, minimo);
			}
		}
		return l;
	}
	
	private void devolver3(int i, Grafo<String> grafo, ListaGenerica<String> actual, ListaGenerica<String> l,
			boolean[] marca, String ciudad2, int distancia, Min minimo) {
		marca[i] = true;
		
		Vertice<String> v = grafo.vertice(i);
		actual.agregarFinal(v.dato());
		
		//System.out.println("ACT= "+v.dato()+" - distancia= "+distancia);
		if (v.dato().equals(ciudad2) && (distancia < minimo.getMinimo())) {
			reemplazar(actual, l);
			minimo.setMinimo(distancia);
		}
		else {
			ListaGenerica<Arista<String>> ady = grafo.listaDeAdyacentes(v);
			ady.comenzar();
			while (!ady.fin()) {
				Arista<String> arista = ady.proximo();
				int j = arista.verticeDestino().posicion();
				if (!marca[j]) {
					devolver3(j, grafo, actual, l, marca, ciudad2, (distancia+arista.peso()), minimo);
					actual.eliminarEn(actual.tamanio());
					marca[j] = false; // desmarco porque puedo llegar a formar un camino desde otro vértice
					// OJO QUE ES CON J NO CON I
				}
			}
		}
	}
	
	
	//----------------------------------------------------------------------------------------------------
	//----------------------------------------------------------------------------------------------------
	
	
	public ListaGenerica<String> caminoSinCargarCombustible(String ciudad1, String ciudad2, int tanqueAuto){
		ListaGenerica<String> l = new ListaEnlazadaGenerica<String>();
		boolean[] marca = new boolean[grafo.listaDeVertices().tamanio() + 1];
		ListaGenerica<Vertice<String>> lis = grafo.listaDeVertices();
		boolean ok = false;
		
		if (!grafo.esVacio() && tanqueAuto > 0) {
			Vertice<String> v = null;
			lis.comenzar();
			while (!lis.fin() && !ok) {
				v = lis.proximo();
				if (v.dato().equals(ciudad1)) {
					ok = true;
				}
			}
			if (ok) {
				devolver4(v.posicion(), grafo, l, marca, ciudad2, tanqueAuto);
			}
		}
		return l;
	}
	
	private boolean devolver4(int i, Grafo<String> grafo, ListaGenerica<String> l, 
			boolean[] marca, String ciudad2, int tanque) {
		boolean ok = false;
		marca[i] = true;
		
		Vertice<String> v = grafo.vertice(i);
		l.agregarFinal(v.dato());
		if (v.dato().equals(ciudad2)) {
			ok =  true;
		}
		else {
			ListaGenerica<Arista<String>> ady = grafo.listaDeAdyacentes(v);
			ady.comenzar();
			while (!ady.fin() && !ok) {
				Arista<String> arista = ady.proximo();
				int j = arista.verticeDestino().posicion();
				if (!marca[j] && (arista.peso() <= tanque))
					ok = devolver4(j,grafo,l,marca, ciudad2, (tanque-arista.peso()));
			}
			if (!ok) {
				l.eliminarEn(l.tamanio());
				marca[i] = false; // desmarco porque puedo llegar a formar un camino desde otro vértice
			}
		}
		return ok;
	}
	
	
	//----------------------------------------------------------------------------------------------------
	//----------------------------------------------------------------------------------------------------
	
	public ListaGenerica<String> caminoConMenorCargaDeCombustible(String ciudad1, String ciudad2, int tanqueAuto){
		
		ListaGenerica<String> actual = new ListaEnlazadaGenerica<String>();
		ListaGenerica<String> l = new ListaEnlazadaGenerica<String>();
		boolean[] marca = new boolean[grafo.listaDeVertices().tamanio() + 1];
		ListaGenerica<Vertice<String>> lis = grafo.listaDeVertices();
		boolean ok = false;
		
		if (!grafo.esVacio() && tanqueAuto > 0) {
			Vertice<String> v = null;
			lis.comenzar();
			while (!lis.fin() && !ok) {
				v = lis.proximo();
				if (v.dato().equals(ciudad1)) {
					ok = true;
				}
			}
			if (ok) {
				Min minimo = new Min(9999);
				int carga = tanqueAuto;
				int cantCargas = 0;
				devolver5(v.posicion(), grafo, actual, l, marca, ciudad2, tanqueAuto, carga, cantCargas, minimo);
			}
		}
		return l;
	}
	
	private void devolver5(int i, Grafo<String> grafo, ListaGenerica<String> actual, ListaGenerica<String> l,
			boolean[] marca, String ciudad2, int tanque, int carga, int cant, Min minimo) {
		marca[i] = true;	
		
		Vertice<String> v = grafo.vertice(i);
		actual.agregarFinal(v.dato());
		//System.out.println("ACTUAL: "+v.dato());
		
		
		if (v.dato().equals(ciudad2) && (cant < minimo.getMinimo())) {
			reemplazar(actual, l);
			minimo.setMinimo(cant);
			//System.out.println(cant);
		}
		else {
			if (tanque == 0) {
				tanque+= carga - tanque;
				cant++;
			}
			ListaGenerica<Arista<String>> ady = grafo.listaDeAdyacentes(v);
			ady.comenzar();
			while (!ady.fin()) {
				Arista<String> arista = ady.proximo();
				int j = arista.verticeDestino().posicion();
				//System.out.println(arista.peso());
				
				if (!marca[j] && ((tanque-arista.peso() >= 0))) {
					devolver5(j,grafo,actual,l,marca, ciudad2, (tanque-arista.peso()), carga, cant, minimo);
					actual.eliminarEn(actual.tamanio());
					marca[j] = false; // desmarco porque puedo llegar a formar un camino desde otro vértice
				}
			}
		}
	}
	
	/*
				while ((tanque-arista.peso() <= 0)) {
					tanque+= carga;
					cant++;
				}
	 */
	
	
}




