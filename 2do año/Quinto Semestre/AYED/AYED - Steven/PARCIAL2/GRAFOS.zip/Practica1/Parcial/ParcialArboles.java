package Parcial;
import PackElementos.*;

public class ParcialArboles{
	
	
	private ArbolBinario<Integer> arbol;
	
	public ParcialArboles (ArbolBinario<Integer> arbol) {
		this.arbol = arbol;
	}
	
	public boolean isLeftTree(int num) {
		boolean ok = false;
		
		if (!arbol.esVacio()) {
			ArbolBinario<Integer> subarbol = new ArbolBinario<Integer>();
			if (encontrar(arbol, num, subarbol)) {
				System.out.println(subarbol.getDato());
				ok = resolver(subarbol);
			}
		}
		
		return ok;
	}
	
	private boolean encontrar (ArbolBinario<Integer> ab, int n, ArbolBinario<Integer> sub) {
		boolean encontre = false;
		
		if (ab.getDato() == n) {
			encontre = true;
			sub = ab;
		} else {
			if (ab.tieneHijoIzquierdo()) {
				encontre = encontrar(ab.getHijoIzquierdo(), n, sub);
			}
			if ((ab.tieneHijoDerecho()) && (!encontre)) {
				encontre = encontrar(ab.getHijoDerecho(), n, sub);
			}
		}
		return encontre;
	}
	
	
	private boolean resolver(ArbolBinario<Integer> a) {
		boolean ok = false;
		int izq = -1;
		int der = -1;
		
		if (a.tieneHijoIzquierdo()) {
			izq = contarHijosUnicos(a.getHijoIzquierdo());
		}
		if (a.tieneHijoDerecho()) {
			der = contarHijosUnicos(a.getHijoDerecho());
		}
		
		
		if (izq > der) {
			ok = true;
		}
		return ok;
	}
	
	
	private int contarHijosUnicos(ArbolBinario<Integer> a) {
		int n = 0;
		
		if (!a.esVacio()) {
			if (!a.tieneHijoIzquierdo()) {
				n = 1 + contarHijosUnicos(a.getHijoDerecho());
			}
			if (!a.tieneHijoDerecho()) {
				n = 1 + contarHijosUnicos(a.getHijoIzquierdo());
			}
		}
		return n;
	}
	
	
	
	
	
	
	
}