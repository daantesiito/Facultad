package Parcial;
import PackElementos.*;

public class ParcialArbolesCorrecion{
	
	private ArbolBinario<Integer> ab;
	
	public ParcialArbolesCorrecion(ArbolBinario<Integer> ab) {
		this.ab = ab;
	}
	
	public boolean isLeftTree(int num) {
		//System.out.println(ab.getDato());
		if (ab.esVacio() || ab.esHoja())
			return false;
		if (!buscarDato(ab, num))
			return false;
		int izq = -1;
		int der = -1;
		if(ab.tieneHijoIzquierdo()) {
			//System.out.println("I");
			izq = contar(ab.getHijoIzquierdo());
		}
		if(ab.tieneHijoDerecho()) {
			//System.out.println("D");
			der = contar(ab.getHijoDerecho());
		}
		System.out.println("Suma izq: " + izq);
		System.out.println("Suma der: " + der);
		return izq > der;
	}
	
	private boolean buscarDato(ArbolBinario<Integer> arbol, int num) {
		if(arbol.getDato().equals(num)) {
			ab = arbol;
			System.out.println("NUMERO ENCONTRADO: " + arbol.getDato());
			return true;
		}
		boolean encontrado = false;
		if(arbol.tieneHijoIzquierdo())
			encontrado = buscarDato(arbol.getHijoIzquierdo(), num);
		if(!encontrado && arbol.tieneHijoDerecho())
			encontrado = buscarDato(arbol.getHijoDerecho(), num);
		//System.out.println(arbol.getDato());
		return encontrado;
	}
	
	private int contar(ArbolBinario<Integer> a) {
		if (a.esHoja())
			return 0;
		int cont = 0;
		if (a.tieneHijoIzquierdo())
			cont = contar(a.getHijoIzquierdo());
		if (a.tieneHijoDerecho())
			cont += contar(a.getHijoDerecho());
		if ((a.tieneHijoIzquierdo() && (!a.tieneHijoDerecho())) || (a.tieneHijoDerecho() && (!a.tieneHijoIzquierdo()))) {
			cont++;
		}
		return cont;
	}
	
	
	
	
	
	
	
}