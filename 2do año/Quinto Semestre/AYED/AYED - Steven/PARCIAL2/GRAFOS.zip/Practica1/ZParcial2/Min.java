package ZParcial2;

public class Min {
	private int minimo;
	
	public Min (int minimo) {
		this.minimo = minimo;
	}

	public int getMinimo () {
		return this.minimo;
	}
	
	public void setMinimo(int minimo) {
		this.minimo = minimo; 
	}
}