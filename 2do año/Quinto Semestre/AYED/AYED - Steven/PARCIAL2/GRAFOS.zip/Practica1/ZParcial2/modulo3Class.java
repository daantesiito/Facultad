package ZParcial2;

import PackElementos.*;
import PackGrafos.*;

public class modulo3Class{
	
	private boolean[] marcarExceptuando(Grafo<String> grafo, ListaGenerica<String> exceptuando) {
		boolean[] devolver = new boolean[grafo.listaDeVertices().tamanio() + 1];
			
		if (!grafo.esVacio()) {
			Vertice<String> v = null;
			exceptuando.comenzar();
			while (!exceptuando.fin()) {
				boolean ok = false;
				String act = exceptuando.proximo();
				//System.out.println("EXCP:" + act);
				ListaGenerica<Vertice<String>> lis = grafo.listaDeVertices();
				lis.comenzar();
				while (!lis.fin() && !ok) {
					v = lis.proximo();
					if (v.dato().equals(act)) {
						//System.out.println("encontre:" + v.dato());
						ok = true;
						devolver[v.posicion()] = true; //LO MARCO COMO VISITADO ASI NO ENTRO EN ESE VERTICE
					}
				}
			}
		}
		return devolver;
	}
	
	public ListaGenerica<String> resolver(Grafo<String> grafo, int metrosMax, ListaGenerica<String> esqNoPermitidas){
		ListaGenerica<String> l = new ListaEnlazadaGenerica<String>();
		ListaGenerica<String> camino = new ListaEnlazadaGenerica<String>();
		
		if (!grafo.esVacio()) {
			boolean[] marca = marcarExceptuando(grafo, esqNoPermitidas);
			ListaGenerica<Vertice<String>> lis = grafo.listaDeVertices();
			Vertice<String> v = null;
			boolean ok = false;
			lis.comenzar();
			while (!lis.fin() && !ok) {
				v = lis.proximo();
				if (v.dato().equals("Municipalidad")) {
					ok = true;
				}
			}
			if (ok)
				dfs(v.posicion(), grafo, l, camino, marca, metrosMax);
		}
		
		return camino;
	}
	
	
	private void dfs(int i, Grafo<String> grafo, ListaGenerica<String> l, ListaGenerica<String> camino,
			boolean[] marca, int metrosMax) {
		
		marca[i] = true;
		Vertice<String> v = grafo.vertice(i);
		l.agregarFinal(v.dato());
		
		if (l.tamanio() > camino.tamanio()) {
			reemplazar(l, camino);
		}
		
		ListaGenerica<Arista<String>> ady = grafo.listaDeAdyacentes(v);
		ady.comenzar();
		while (!ady.fin()) {
			Arista<String> arista = ady.proximo();
			int j = arista.verticeDestino().posicion();
			int peso = arista.peso();
			if (!marca[j] && (metrosMax-peso) >= 0) {
				dfs(j, grafo, l, camino, marca, (metrosMax-peso));
				l.eliminarEn(l.tamanio());
				marca[j] = false;
			}
		}
	}
	
	
	
	
	private void reemplazar(ListaGenerica<String> l, ListaGenerica<String> camino) {
		camino.comenzar();
		while (!camino.fin()) {
			camino.eliminar(camino.proximo());
		}
		l.comenzar();
		while (!l.fin()) {
			camino.agregarFinal(l.proximo());
		}
	}
	
	
	
	
	
	
	
	
	
	
}