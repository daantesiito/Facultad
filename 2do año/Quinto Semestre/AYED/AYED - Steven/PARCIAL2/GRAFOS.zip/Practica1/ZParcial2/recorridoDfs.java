package ZParcial2;

import PackElementos.*;
import PackGrafos.*;

public class recorridoDfs {
	
	public ListaGenerica<String> devolverCamino(Grafo<String> grafo, String origen, String destino) {
		ListaGenerica<String> l = new ListaEnlazadaGenerica<String>();
		
		if (!grafo.esVacio()) {
			boolean[] marca = new boolean[(grafo.listaDeVertices().tamanio() + 1)];
			ListaGenerica<Vertice<String>> lis = grafo.listaDeVertices();
			boolean ok = false;
			Vertice<String> v = null;
			lis.comenzar();
			while (!lis.fin() && !ok) {
				v = lis.proximo();
				if (v.dato().equals(origen)) {
					ok = true;
				}
			}
			if (ok)
				dfs1(v.posicion(), grafo, l, marca, destino);
		}
		
		return l;
	}
	
	private boolean dfs1(int i, Grafo<String> grafo, ListaGenerica<String> l, 
			boolean[] marca, String destino) {
		
		boolean ok = false;
		marca[i] = true;
		
		Vertice<String> v = grafo.vertice(i);
		l.agregarFinal(v.dato());
		
		if (v.dato().equals(destino)) {
			ok = true;
		}else {
			ListaGenerica<Arista<String>> ady = grafo.listaDeAdyacentes(v);
			ady.comenzar();
			while (!ady.fin() && !ok) {
				Arista<String> arista = ady.proximo();
				int j = arista.verticeDestino().posicion();
				if (!marca[j]) {
					ok = dfs1(j, grafo, l, marca, destino);
				}
			}
			if (!ok) {
				marca[i] = false;
				l.eliminarEn(l.tamanio());
			}
		}
		return ok;
	}
	
	
	//----------------------------------------------------------------------------------------------------
	//----------------------------------------------------------------------------------------------------
		
	
	private boolean[] marcarExceptuando(Grafo<String> grafo, ListaGenerica<String> exceptuando) {
		boolean[] devolver = new boolean[(grafo.listaDeVertices().tamanio() + 1)];
		ListaGenerica<Vertice<String>> lis = grafo.listaDeVertices();
		
		exceptuando.comenzar();
		while (!exceptuando.fin()) {
			String act = exceptuando.proximo();
			boolean ok = false;
			lis.comenzar();
			while (!lis.fin() && !ok) {
				Vertice<String> v = lis.proximo();
				if (v.dato().equals(act)) {
					ok = true;
					devolver[v.posicion()]=true;
				}
			}
		}
		
		return devolver;
	}
	
	public ListaGenerica<String> devolverCaminoExceptuando(Grafo<String> grafo, String origen, String destino, ListaGenerica<String> exceptuando) {
		ListaGenerica<String> l = new ListaEnlazadaGenerica<String>();
		
		if (!grafo.esVacio()) {
			boolean[] marca = marcarExceptuando(grafo, exceptuando);
			ListaGenerica<Vertice<String>> lis = grafo.listaDeVertices();
			boolean ok = false;
			Vertice<String> v = null;
			lis.comenzar();
			while (!lis.fin() && !ok) {
				v = lis.proximo();
				if (v.dato().equals(origen)) {
					ok = true;
				}
			}
			if (ok)
				dfs2(v.posicion(), grafo, l, marca, destino);
		}
		
		return l;
	}
	
	private boolean dfs2(int i, Grafo<String> grafo, ListaGenerica<String> l, 
			boolean[] marca, String destino) {
		
		boolean ok = false;
		marca[i] = true;
		
		Vertice<String> v = grafo.vertice(i);
		l.agregarFinal(v.dato());
		
		if (v.dato().equals(destino)) {
			ok = true;
		}else {
			ListaGenerica<Arista<String>> ady = grafo.listaDeAdyacentes(v);
			ady.comenzar();
			while (!ady.fin() && !ok) {
				Arista<String> arista = ady.proximo();
				int j = arista.verticeDestino().posicion();
				if (!marca[j]) {
					ok = dfs2(j, grafo, l, marca, destino);
				}
			}
			if (!ok) {
				marca[i] = false;
				l.eliminarEn(l.tamanio());
			}
		}
		return ok;
	}

	
	//----------------------------------------------------------------------------------------------------
	//----------------------------------------------------------------------------------------------------
	
	
	public ListaGenerica<String> caminoMasCorto(Grafo<String> grafo, String origen, String destino) {
		ListaGenerica<String> l = new ListaEnlazadaGenerica<String>();
		ListaGenerica<String> camino = new ListaEnlazadaGenerica<String>();
		
		if (!grafo.esVacio()) {
			Min minimo = new Min(9999);
			int dist = 0;
			boolean[] marca = new boolean[(grafo.listaDeVertices().tamanio() + 1)];
			ListaGenerica<Vertice<String>> lis = grafo.listaDeVertices();
			boolean ok = false;
			Vertice<String> v = null;
			lis.comenzar();
			while (!lis.fin() && !ok) {
				v = lis.proximo();
				if (v.dato().equals(origen)) {
					ok = true;
				}
			}
			if (ok)
				dfs3(v.posicion(), grafo, l, camino, marca, destino, minimo, dist);
		}
		
		return camino;
	}
	
	private void dfs3(int i, Grafo<String> grafo, ListaGenerica<String> l, ListaGenerica<String> camino,
			boolean[] marca, String destino, Min minimo, int distancia) {
		marca[i] = true;
		
		Vertice<String> v = grafo.vertice(i);
		l.agregarFinal(v.dato());
		
		if (v.dato().equals(destino) && distancia < minimo.getMinimo()) {
			reemplazar(l, camino);
			minimo.setMinimo(distancia);
		}else {
			ListaGenerica<Arista<String>> ady = grafo.listaDeAdyacentes(v);
			ady.comenzar();
			while (!ady.fin()) {
				Arista<String> arista = ady.proximo();
				int j = arista.verticeDestino().posicion();
				if (!marca[j]) {
					dfs3(j, grafo, l, camino, marca, destino, minimo, (distancia+arista.peso()));
					marca[j] = false;
					l.eliminarEn(l.tamanio());
				}
			}
		}
	}
	
	private void reemplazar(ListaGenerica<String> l, ListaGenerica<String> camino) {
		camino.comenzar();
		while (!camino.fin()) {
			camino.eliminar(camino.proximo());
		}
		l.comenzar();
		while (!l.fin()) {
			camino.agregarFinal(l.proximo());
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
}