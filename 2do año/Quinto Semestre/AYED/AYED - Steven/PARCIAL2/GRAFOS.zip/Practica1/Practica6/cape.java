package Practica6;

import PackElementos.*;
import PackGrafos.*;

public class cape{
	
	public static void main(String[] args) {
		Vertice<String> v1 = new VerticeImplListAdy<String>("Casa Caperucita");
		Vertice<String> v2 = new VerticeImplListAdy<String>("Claro 3");
		Vertice<String> v3 = new VerticeImplListAdy<String>("Claro 1");
		Vertice<String> v4 = new VerticeImplListAdy<String>("Claro 2");
		Vertice<String> v5 = new VerticeImplListAdy<String>("Claro 5");
		Vertice<String> v6 = new VerticeImplListAdy<String>("Claro 4");
		Vertice<String> v7 = new VerticeImplListAdy<String>("Casa Abuela");

		Grafo<String> ciudades = new GrafoImplListAdy<String>();
		
		ciudades.agregarVertice(v1);
		ciudades.agregarVertice(v2);
		ciudades.agregarVertice(v3);
		ciudades.agregarVertice(v4);
		ciudades.agregarVertice(v5);
		ciudades.agregarVertice(v6);
		ciudades.agregarVertice(v7);

		ciudades.conectar(v1, v2, 4);
		ciudades.conectar(v1, v3, 3);
		ciudades.conectar(v1, v4, 4);
		
		ciudades.conectar(v2, v5, 15);
		ciudades.conectar(v3, v5, 3);
		ciudades.conectar(v4, v5, 11);
		
		ciudades.conectar(v5, v7, 4);
		
		ciudades.conectar(v4, v6, 10);
		
		ciudades.conectar(v6, v7, 9);

		/*
		Recorridos<String> r = new Recorridos<String>();
		System.out.println("--- Se imprime el GRAFO con DFS ---");
		ListaGenerica <Vertice<String>> lis = r.dfs(ciudades);
		lis.comenzar();
		while(!lis.fin()) {
			System.out.println(lis.proximo().dato());
		}
		System.out.println(" ");
		System.out.println("--- Se imprime el GRAFO con BFS ---");
		ListaGenerica <Vertice<String>> lis2 = r.bfs(ciudades);
		lis2.comenzar();
		while(!lis2.fin()) {
			System.out.println(lis2.proximo().dato());
		}
		*/
		
		Caperucita<String> cap = new Caperucita<String>();
		System.out.println("--- Se imprime el GRAFO CAPERUCITA ---");
		ListaGenerica <Vertice<String>> lis3 = cap.dfs(ciudades);
		lis3.comenzar();
		while(!lis3.fin()) {
			System.out.println(lis3.proximo().dato());
		}
	}
	
}