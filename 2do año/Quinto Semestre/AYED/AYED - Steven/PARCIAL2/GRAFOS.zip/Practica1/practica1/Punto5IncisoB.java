package practica1;

public class Punto5IncisoB {
    private int min;
    private int max;
    private double prom;

    public Punto5IncisoB(int min, int max, double prom) {
        this.min = min;
        this.max = max;
        this.prom = prom;
    }
    
    
    
    
    public int getMax() {
        return max;
    }
    public void setMax(int max) {
        this.max = max;
    }
    public int getMin() {
        return min;
    }
    public void setMin(int min) {
        this.min = min;
    }
    public double getProm() {
        return prom;
    }
    public void setProm(double prom) {
        this.prom = prom;
    }
    
    @Override
    public String toString() {
        return "Max: " + this.max + ", min: " + this.min + ", promedio: " + this.prom;
    }
    
}
