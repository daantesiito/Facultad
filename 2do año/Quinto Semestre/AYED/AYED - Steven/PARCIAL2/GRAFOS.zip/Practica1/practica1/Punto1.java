package practica1;
import java.util.Scanner;

/**
 *
 * @author Esteban
 */
public class Punto1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner escaner = new Scanner(System.in) ;
        
        System.out.print("Ingrese un numero: ");
        int a = escaner.nextInt();

        System.out.print("Ingrese otro numero: ");
        int b = escaner.nextInt();
        
        imprimirFor(a,b);
        System.out.println();
        imprimirWhile(a, b);
        System.out.println();
        
        imprimir(a, b);
        escaner.close();
        
        
    }
    
    
    public static void imprimirFor (int a, int b){
        for(int i = a; i <= b; i++){
            System.out.println(i);
        }
    }
    
    
    public static void imprimirWhile (int a, int b){
        while (a <= b){
            System.out.println(a);
            a++;
        }
    }
    
    public static void imprimir (int a, int b){
        if (a <= b){
            System.out.println(a);
            imprimir(++a, b);
        }
    }
    
}
