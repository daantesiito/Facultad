package practica1;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Esteban
 */
public class Estudiante {
    
    private String nombre;
    private String apellido;
    private String comision;
    private String mail;
    private String direccion;

    public Estudiante(String nombre, String apellido, String comision, String mail, String direccion) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.comision = comision;
        this.mail = mail;
        this.direccion = direccion;
    }
    
    

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public void setComision(String comision) {
        this.comision = comision;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public String getComision() {
        return comision;
    }

    public String getMail() {
        return mail;
    }

    public String getDireccion() {
        return direccion;
    }

    
    
    public String tusDatos() {
        return "Nombre: " + this.getNombre() + " " + this.getApellido() + ", comision: " + this.getComision()
                + ", mail: " + this.getMail() + ", direccion:" + this.getDireccion();
    }
    
    
    
    
}
