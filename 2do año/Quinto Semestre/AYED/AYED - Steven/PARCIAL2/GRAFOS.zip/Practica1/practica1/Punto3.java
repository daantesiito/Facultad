package practica1;
import java.util.Scanner;
import java.util.Random;

/**
 *
 * @author Esteban
 */
public class Punto3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner escaner = new Scanner(System.in);
        
        int estu = 2;
        int profes = 3;
        
        Estudiante []estudiantes = new Estudiante[estu];
        
        Profesor []profesores = new Profesor[profes];
        
        estudiantes[0] = new Estudiante("Esteban", "MR", "1A","gmail.com","74 esquina 115");
        estudiantes[1] = new Estudiante("Camilo", "M", "1B","hotmail.com","1y72");

        profesores[0] = new Profesor("Carlos","R","gmail.com","CADP","UNLP");
        profesores[1] = new Profesor("Roberto","P","hotmail.com","Taller","UNLP");
        profesores[2] = new Profesor("Juan","T","mail.com","Seminario","UNLP");
        
        
        for (int i = 0; i < estu; i++){
            System.out.println(estudiantes[i].tusDatos());
        }
        
        for (int i = 0; i < profes; i++){
            System.out.println(profesores[i].tusDatos());
        }
        
    }
        
    
}
