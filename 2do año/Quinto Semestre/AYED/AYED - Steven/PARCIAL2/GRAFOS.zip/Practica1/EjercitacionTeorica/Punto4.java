/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EjercitacionTeorica;

import PackElementos.*;

/**
 *
 * @author Esteban
 */
public class Punto4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        //              C
        //           /      \
        //          A        E
        //           \      / \
        //            B    D   F
        
        ArbolBinario<String> padre = new ArbolBinario("C");
        ArbolBinario<String> hijoIzq = new ArbolBinario("A");
        ArbolBinario<String> hijoDer = new ArbolBinario("E");
        ArbolBinario<String> b = new ArbolBinario("B");
        ArbolBinario<String> d = new ArbolBinario("D");
        ArbolBinario<String> f = new ArbolBinario("F");
        
        
        padre.agregarHijoIzquierdo(hijoIzq);
        padre.agregarHijoDerecho(hijoDer);
        
        hijoIzq.agregarHijoDerecho(b);
        
        hijoDer.agregarHijoIzquierdo(d);
        hijoDer.agregarHijoDerecho(f);

        System.out.println("Su arbol tiene "+padre.contarNodos()+" nodos");
        System.out.println("Su arbol tiene "+padre.contarHojas()+" hojas");
        System.out.println("Su arbol tiene una altura de "+padre.altura());
        System.out.println("-------INORDEN--------");
        padre.printInorden();
        System.out.println("-------POSTORDEN-------");
        padre.printPostorden();
        System.out.println("-------PREORDEN--------");
        padre.printPreorden();
        System.out.println("-------POR NIVELES------");
        padre.printPorNiveles();
        System.out.println("-------ENTRE NIVELES-----");
        padre.entreNiveles(1,2);
        
        ArbolBinario<String> arbolEspejo = padre.espejo();
        System.out.println("----PREORDEN ESPEJO---");
        arbolEspejo.printPreorden();

        if(padre.esLleno()){
            System.out.println("ES LLENO");
        }else{
            System.out.println("NO ES LLENO");
        }
        
        System.out.println("---- TRAVERSE ---");
        padre.traverse(padre);
    }
    
}
