package Practica2;

/**
 *
 * @author Esteban
 */
public class Ejercicio1e {
    
    public static void imprimirInverso(ListaDeEnteros l, int numero){
        if (numero > 0){
            System.out.println(l.elemento(numero));
            imprimirInverso(l, --numero);
        }
    }
    
    
    public static void main (String[] args){
        ListaDeEnterosConArreglos L = new ListaDeEnterosConArreglos();
        L.agregarFinal(1);
        L.agregarFinal(3);
        L.agregarFinal(6);
        imprimirInverso(L,L.tamanio());
    }
    
}
