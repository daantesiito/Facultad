/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Practica2;

/**
 *
 * @author Esteban
 */
public class TestListaEnlazadaGenerica {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Estudiante estu1 = new Estudiante("A","B1","C1","D1","E1");
        Estudiante estu2 = new Estudiante("R","B2","C2","D2","E2");
        Estudiante estu3 = new Estudiante("F","B3","C3","D3","E3");
        Estudiante estu4 = new Estudiante("G","B4","C4","D4","E4");
        
        
        ListaEnlazadaGenerica<Estudiante> lista= new ListaEnlazadaGenerica<Estudiante>();
        lista.comenzar();
        lista.agregarFinal(estu1);
        lista.agregarFinal(estu2);
        lista.agregarFinal(estu3);
        lista.agregarFinal(estu4);
        
        lista.comenzar();
        
        for (int i = 1; i <= lista.tamanio(); i++){
            System.out.println(lista.elemento(i).tusDatos());
        }
        
        Integer[] numeros = {10, 213, 312, 41, 53, 5324, 42};
        ListaEnlazadaGenerica l1 = new ListaEnlazadaGenerica();
        if (l1.agregar(numeros)) {
            l1.comenzar();
            for (int i = 1; i <= l1.tamanio(); i++) {
                System.out.println(l1.elemento(i));
            }   
        }
    }
    
}
