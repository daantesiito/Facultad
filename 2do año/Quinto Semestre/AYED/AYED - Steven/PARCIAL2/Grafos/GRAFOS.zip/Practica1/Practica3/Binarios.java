package Practica3;
import PackElementos.*;
/**
 *
 * @param <T>
 */
public class Binarios<T> {
	
	public static ArbolBinario<Character> convertirPostfija(String exp){
		Character c = null;
		ArbolBinario<Character> result;
		PilaGenerica<ArbolBinario<Character>> p = new PilaGenerica<ArbolBinario<Character>>();


		for (int i = 0; i < exp.length(); i++){
			c = exp.charAt(i);
			result = new ArbolBinario<Character>(c);
			if ((c == '+') || (c == '-') || (c == '/') || (c == '*')){
				// es operador
				result.agregarHijoDerecho(p.desapilar());
				result.agregarHijoIzquierdo(p.desapilar());
			}
			p.apilar(result);
		}
		return (p.desapilar());
	}
	
	public static ArbolBinario<Character> convertirPrefija(StringBuffer exp){
		Character c = exp.charAt(0);
		ArbolBinario<Character> result = new ArbolBinario<Character>(c);
		
		if ((c == '+') || (c == '-') || (c == '/') || (c == '*')){
			// es operador
			result.agregarHijoDerecho(convertirPrefija(exp.delete(0,  1)));
			result.agregarHijoIzquierdo(convertirPrefija(exp.delete(0,  1)));
		}
		
		return result;
	}

	public static Integer evaluar(ArbolBinario<Character> arbol) {
		Character c = arbol.getDato();
		
		if ((c == '+') || (c == '-') || (c == '/') || (c == '*')){
			// es operador
			int operador_1 = evaluar(arbol.getHijoIzquierdo());
			int operador_2 = evaluar(arbol.getHijoDerecho());
			
			switch(c) {
				case '+': return operador_1 + operador_2;
				case '-': return operador_1 - operador_2;
				case '/': return operador_1 / operador_2;
				case '*': return operador_1 * operador_2;
			}
		}
		
		return Integer.parseInt(c.toString());
	}
	
		
	public static void main(String[] args) {
		ArbolBinario<Character> a = convertirPostfija("ab+c*de+/");
		/*System.out.println("-------INORDEN--------");
        a.printInorden();
        System.out.println("-------POSTORDEN-------");
        a.printPostorden();
        System.out.println("-------PREORDEN--------");
        a.printPreorden();*/
		System.out.println("-------POSTORDEN-------");
        a.printPostorden();
        
        StringBuffer str = new StringBuffer("/*+abc+de");
        ArbolBinario<Character> a2 = convertirPrefija(str);
        System.out.println("-------PREORDEN--------");
        a.printPreorden();
        
        ArbolBinario<Character> a3 = convertirPostfija("12+9*21+/");
        Integer inte = evaluar(a3);
        System.out.println(inte);
	}
	
	
		
}


