package Practica6;

import PackElementos.*;
import PackGrafos.*;

public class Caperucita<T>{
	
	public ListaGenerica<Vertice<T>> dfs (Grafo<T> grafo){
		boolean[]marca = new boolean[grafo.listaDeVertices().tamanio() + 1];
		ListaEnlazadaGenerica<Vertice<T>> lis = new ListaEnlazadaGenerica<Vertice<T>>();
		for (int i=1; i<=grafo.listaDeVertices().tamanio(); i++) {
			Vertice<T> v = grafo.listaDeVertices().elemento(i);
			//System.out.println();
			if ((!marca[i]) && (v.dato() == "Casa Caperucita"))
				dfs(i,grafo,lis,marca);
		}
		return lis;
	}
	
	private boolean dfs (int i,Grafo<T> grafo,ListaEnlazadaGenerica<Vertice<T>> lis, boolean[] marca) {
		boolean ok = false;
		
		marca[i] = true;
		Vertice<T> v = grafo.listaDeVertices().elemento(i); // ESTO ES LO MAS IMPORTANTE
		lis.agregarFinal(v);
		//System.out.println("DATO ACT: " + lis.elemento(lis.tamanio()).dato());
		if (v.dato().equals("Casa Abuela"))
			return true;
		ListaGenerica<Arista<T>> ady = grafo.listaDeAdyacentes(v);
		ady.comenzar();
		while (!ady.fin() && !ok) {
			Arista<T> arista = ady.proximo();
			int j = arista.verticeDestino().posicion();
			if (!marca[j]){
				int p = arista.peso();
				if (p<5){
					ok = dfs(j,grafo,lis,marca);
					if (!ok) {
						lis.eliminarEn(lis.tamanio());
					} // se pone en el if si no al volver del primer dfs se borra el primer elem
				}
			}
		}
		return ok;
	}
	
}
