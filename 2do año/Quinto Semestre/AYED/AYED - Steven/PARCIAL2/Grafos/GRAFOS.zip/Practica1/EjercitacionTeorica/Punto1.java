/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EjercitacionTeorica;

import PackElementos.*;

/**
 *
 * @author Esteban
 */
public class Punto1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        //              D
        //           /      \
        //         B         H
        //       /   \      / \
        //      A     E    J   C
    	//          /  \      /
	    //         G    F    I
        
        ArbolBinario<String> d = new ArbolBinario("D");
        ArbolBinario<String> b = new ArbolBinario("B");
        ArbolBinario<String> a = new ArbolBinario("A");
        ArbolBinario<String> e = new ArbolBinario("E");
        ArbolBinario<String> g = new ArbolBinario("G");
        ArbolBinario<String> f = new ArbolBinario("F");
        
        ArbolBinario<String> c = new ArbolBinario("C");
        ArbolBinario<String> j = new ArbolBinario("J");
        ArbolBinario<String> h = new ArbolBinario("H");
        ArbolBinario<String> i = new ArbolBinario("I");
        
        
        d.agregarHijoIzquierdo(b);
        d.agregarHijoDerecho(h);
        
        e.agregarHijoIzquierdo(g);
        e.agregarHijoDerecho(f);
        
        b.agregarHijoIzquierdo(a);
        b.agregarHijoDerecho(e);
        
        h.agregarHijoIzquierdo(j);
        h.agregarHijoDerecho(c);
        c.agregarHijoIzquierdo(i);

        System.out.println("Su arbol tiene "+d.contarNodos()+" nodos");
        System.out.println("Su arbol tiene "+d.contarHojas()+" hojas");
        System.out.println("Su arbol tiene una altura de "+d.altura());
        System.out.println("-------INORDEN--------");
        d.printInorden();
        System.out.println("-------POSTORDEN-------");
        d.printPostorden();
        System.out.println("-------PREORDEN--------");
        d.printPreorden();
        System.out.println("-------POR NIVELES------");
        d.printPorNiveles();
        System.out.println("-------ENTRE NIVELES-----");
        d.entreNiveles(1,2);
        
        ArbolBinario<String> arbolEspejo = d.espejo();
        System.out.println("----PREORDEN ESPEJO---");
        arbolEspejo.printPreorden();

        if(d.esLleno()){
            System.out.println("ES LLENO");
        }else{
            System.out.println("NO ES LLENO");
        }
    }
    
}
