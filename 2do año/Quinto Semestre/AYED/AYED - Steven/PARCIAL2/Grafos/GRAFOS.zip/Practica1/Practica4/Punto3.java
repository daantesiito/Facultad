package Practica4;
import PackElementos.*;

public class Punto3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    	//      	13
	    //         /  \
	    //        53  17
	    //       /    / \
	    //      12   33 102
	    ArbolGeneral<Integer> a13 = new ArbolGeneral<Integer>(13);
	    ArbolGeneral<Integer> a53 = new ArbolGeneral<Integer>(53);
	    ArbolGeneral<Integer> a12 = new ArbolGeneral<Integer>(12);
	    ArbolGeneral<Integer> a17 = new ArbolGeneral<Integer>(17);
	    ArbolGeneral<Integer> a33 = new ArbolGeneral<Integer>(33);
	    ArbolGeneral<Integer> a102 = new ArbolGeneral<Integer>(102);
        
	    a13.agregarHijo(a53);
	    a53.agregarHijo(a12);
	    a13.agregarHijo(a17);
	    a17.agregarHijo(a33);
	    a17.agregarHijo(a102);
	    
	    
	    System.out.println("ARBOL GENERAL CON UNA ALTURA DE: " + a13.altura());
	    
	    
	    System.out.println("ARBOL PRE ORDEN: ");
	    a13.printpreOrden();
	    
	    System.out.println("ARBOL IN ORDEN: ");
	    a13.printinOrden();
	    
	    System.out.println("ARBOL POST ORDEN: ");
	    a13.printpostOrden();
	    
	    System.out.println("ARBOL POR NIVELES ORDEN: ");
	    a13.printPorNiveles();
	    
	    System.out.println();
	    
	    System.out.println("LISTA NUMEROS IMPARES MAYORES QUE 12 PRE ORDEN: ");
	    RecorridosAG rec = new RecorridosAG();
	    ListaGenerica<Integer> listaPreOrden = rec.numerosImparesMayoresQuePreOrden(a13, 12);
	    listaPreOrden.comenzar();
	    while (!listaPreOrden.fin()) {
	    	System.out.print(listaPreOrden.proximo() + " ");
	    }
	    
	    System.out.println();
	    System.out.println("LISTA NUMEROS IMPARES MAYORES QUE 12 IN ORDEN: ");
	    ListaGenerica<Integer> listaInOrden = rec.numerosImparesMayoresQueInOrden(a13, 12);
	    listaInOrden.comenzar();
	    while (!listaInOrden.fin()) {
	    	System.out.print(listaInOrden.proximo() + " ");
	    }
	    
	    System.out.println();
	    System.out.println("LISTA NUMEROS IMPARES MAYORES QUE 12 POST ORDEN: ");
	    ListaGenerica<Integer> listaPostOrden = rec.numerosImparesMayoresQuePostOrden(a13, 12);
	    listaPostOrden.comenzar();
	    while (!listaPostOrden.fin()) {
	    	System.out.print(listaPostOrden.proximo() + " ");
	    }
	    
	    System.out.println();
	    System.out.println("LISTA NUMEROS IMPARES MAYORES QUE 12 POR NIVELES (0 separa niveles): ");
	    ListaGenerica<Integer> listaPorNiveles = rec.numerosImparesMayoresQuePorNiveles(a13, 12);
	    listaPorNiveles.comenzar();
	    while (!listaPorNiveles.fin()) {
	    	System.out.print(listaPorNiveles.proximo() + " ");
	    }
	    
	    System.out.println();
	    int dato = 102;
	    int nivel = a13.nivel(dato);
	    if (nivel != -1 ) {
	    	System.out.println("El nivel del nodo con el dato " + dato + " es " + nivel);
	    }
	    else {
	    	System.out.println("El nodo con el dato " + dato + " no se encontró en el arbol");
	    }
	    
	    System.out.println();
	    int dato2 = 102;
	    int nivel2 = a13.nivel2(dato2);
	    if (nivel2 != -1 ) {
	    	System.out.println("El nivel del nodo con el dato " + dato2 + " es " + nivel2);
	    }
	    else {
	    	System.out.println("El nodo con el dato " + dato2 + " no se encontró en el arbol");
	    }
	    
	    
	    System.out.println();
	    System.out.println("El arbol tiene un ancho de: " + a13.ancho());
	    
	    System.out.println();
	    int nodoDes = 102;
	    int nodoPad = 17;
	    if (a13.esAncestro(nodoPad, nodoDes)) {
	    	System.out.println("El nodo " + nodoPad + " es ANCESTRO del nodo " + nodoDes);
	    }
	    else {
	    	System.out.println("El nodo " + nodoPad + " NO es ANCESTRO del nodo " + nodoDes);
	    }
	    
	    
	    System.out.println();
	    System.out.println("----- ES ANCESTRO RECURSIVO -----");
	    System.out.println();
	    int nodoDes2 = 102;
	    int nodoPad2 = 17;
	    if (a13.esAncestro(nodoPad2, nodoDes2)) {
	    	System.out.println("El nodo " + nodoPad2 + " es ANCESTRO del nodo " + nodoDes2);
	    }
	    else {
	    	System.out.println("El nodo " + nodoPad2 + " NO es ANCESTRO del nodo " + nodoDes2);
	    }
	   
    }
    
}
