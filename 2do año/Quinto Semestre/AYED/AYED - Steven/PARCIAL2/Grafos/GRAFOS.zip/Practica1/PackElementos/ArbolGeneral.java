package PackElementos;

public class ArbolGeneral<T> {

	private T dato;

	private ListaGenerica<ArbolGeneral<T>> hijos = new ListaEnlazadaGenerica<ArbolGeneral<T>>();

	public T getDato() {
		return dato;
	}

	public void setDato(T dato) {
		this.dato = dato;
	}

	public void setHijos(ListaGenerica<ArbolGeneral<T>> hijos) {
		if (hijos==null)
			this.hijos = new ListaEnlazadaGenerica<ArbolGeneral<T>>();
		else
			this.hijos = hijos;
	}

	public ArbolGeneral(T dato) {
		this.dato = dato;
	}

	public ArbolGeneral(T dato, ListaGenerica<ArbolGeneral<T>> hijos) {
		this(dato);
		if (hijos==null)
			this.hijos = new ListaEnlazadaGenerica<ArbolGeneral<T>>();
		else
			this.hijos = hijos;
	}

	public ListaGenerica<ArbolGeneral<T>> getHijos() {
		return this.hijos;
	}

	public void agregarHijo(ArbolGeneral<T> unHijo) {
		this.getHijos().agregarFinal(unHijo);
	}

	public boolean esHoja() {

		return !this.tieneHijos();
	}
	
	public boolean tieneHijos() {
		return !this.hijos.esVacia();
	}
	
	public boolean esVacio() {

		return this.dato == null && !this.tieneHijos();
	}

	

	public void eliminarHijo(ArbolGeneral<T> hijo) {
		if (this.tieneHijos()) {
			ListaGenerica<ArbolGeneral<T>> hijos = this.getHijos();
			if (hijos.incluye(hijo))
				hijos.eliminar(hijo);
		}
	}
	
	/*
	public void preOrden() {
		imprimir (dato);
		obtener lista de hijos;
		mientras (lista tenga datos) {
			hijo obtenerHijo;
			hijo.preOrden();
		}
	}
	 */
	
	/*public Integer altura() {
        ColaGenerica <ArbolGeneral<T>> cola = new ColaGenerica<ArbolGeneral<T>>();
        ArbolGeneral <T> arbol;
        cola.encolar(this);
        cola.encolar(null);
        int altura = 0;
        while(!cola.esVacia()){
            arbol=cola.desencolar();
            if(arbol != null){
                ListaGenerica<ArbolGeneral<T>> lHijos = arbol.getHijos();
                lHijos.comenzar();
                while (!lHijos.fin()) {
                	cola.encolar(lHijos.proximo());
                }
            }else if (!cola.esVacia()){
                cola.encolar(null);
                altura+=1;
            }
        }
        return altura;
    }*/
	
	public int altura() {
	    if (this.esHoja()) { // Si el árbol es una hoja, su altura es 0.
	        return 0;
	    } else {
	        int alturaMax = 0;
	        ListaGenerica<ArbolGeneral<T>> lHijos = this.getHijos();
	        lHijos.comenzar();
	        while (!lHijos.fin()) {
	            int alturaHijo = lHijos.proximo().altura(); // Recursivamente calculamos la altura de cada hijo.
	            alturaMax = Math.max(alturaMax, alturaHijo); // Tomamos el máximo de las alturas de los hijos.
	        }
	        return alturaMax + 1; // La altura del árbol es el máximo de las alturas de los hijos más 1 (por la raíz).
	    }
	}
	
	

	public Integer nivel(T dato) {
		ColaGenerica <ArbolGeneral<T>> cola = new ColaGenerica<ArbolGeneral<T>>();
        ArbolGeneral <T> arbol;
        cola.encolar(this);
        cola.encolar(null);
        int altura = 0;
        while(!cola.esVacia()){
            arbol=cola.desencolar();
            if(arbol != null){
            	if (arbol.getDato() == dato) {
            		return altura;
            	}
                ListaGenerica<ArbolGeneral<T>> lHijos = arbol.getHijos();
                lHijos.comenzar();
                while (!lHijos.fin()) {
                	cola.encolar(lHijos.proximo());
                }
            }else if (!cola.esVacia()){
                cola.encolar(null);
                altura++;
            }
        }
		
		return -1;
	}
	
	
	public int nivel2(T dato) {
	    return nivelRecursivo(this, dato, 0);
	}

	private int nivelRecursivo(ArbolGeneral<T> arbol, T dato, int nivelActual) {
	    if (arbol == null) { // Si el árbol es nulo, el dato no se encuentra y retornamos -1.
	        return -1;
	    } else if (arbol.getDato().equals(dato)) { // Si el dato se encuentra en la raíz del árbol, retornamos el nivel actual.
	        return nivelActual;
	    } else { // Si no, buscamos el dato en los hijos recursivamente.
	        ListaGenerica<ArbolGeneral<T>> hijos = arbol.getHijos();
	        hijos.comenzar();
	        while (!hijos.fin()) {
	            ArbolGeneral<T> hijo = hijos.proximo();
	            int nivelHijo = nivelRecursivo(hijo, dato, nivelActual + 1); // Llamada recursiva para buscar en el hijo.
	            if (nivelHijo != -1) { // Si encontramos el dato en alguno de los hijos, retornamos el nivel del hijo.
	                return nivelHijo;
	            }
	        }
	        return -1; // Si no encontramos el dato en ningún hijo, retornamos -1.
	    }
	}

	
	

	/*public Integer ancho() {
		// Falta implementar..	
		return 0;
	}*/
	
	public int ancho() {
		Integer ancho = -1;
        Integer cantNodos = 0;
        ArbolGeneral<T> arbol;
        ColaGenerica<ArbolGeneral<T>> cola = new ColaGenerica<ArbolGeneral<T>>();
        cola.encolar(this);
        cola.encolar(null);
        while(!cola.esVacia()) {
            arbol = cola.desencolar();
            if(arbol !=null) {
                ListaGenerica<ArbolGeneral<T>> lHijos = arbol.getHijos();
                lHijos.comenzar();
                cantNodos++;
                while(!lHijos.fin()) {
                    cola.encolar(lHijos.proximo());
                }
                if (cantNodos > ancho) {
                	ancho = cantNodos;
                }
            }else if(!cola.esVacia()) {
                cola.encolar(null);

                cantNodos = 0;
            }
        }
        return ancho;
    }
	
	
	public ListaEnlazadaGenerica<T> preOrden(){
        ListaEnlazadaGenerica<T> l = new ListaEnlazadaGenerica<T>();
        this.preOrden(l);
        return l;
    }
    private void preOrden(ListaGenerica<T> l) {
        //raiz, hijos
        l.agregarFinal(this.getDato());
        ListaGenerica<ArbolGeneral<T>> lHijos = this.getHijos();
        lHijos.comenzar();
        while(!lHijos.fin()) {
            (lHijos.proximo()).preOrden(l);
        }
    }
    
    public ListaEnlazadaGenerica<T> posOrden(){
        ListaEnlazadaGenerica<T> l = new ListaEnlazadaGenerica<T>();
        this.posOrden(l);
        return l;
    }
    
    private void posOrden(ListaGenerica<T> l) {
        //hijos, raiz
        ListaGenerica<ArbolGeneral<T>> lHijos = this.getHijos();
        lHijos.comenzar();
        while(!lHijos.fin()) {
            (lHijos.proximo()).posOrden(l);
        }
        l.agregarFinal(this.getDato());
    }
    
    public ListaEnlazadaGenerica<T> inOrden(){
        ListaEnlazadaGenerica<T> l = new ListaEnlazadaGenerica<T>();
        this.inOrden(l);
        return l;
    }
    
    private void inOrden(ListaGenerica<T> l) {
        //primer hijo, raiz, hijos
        ListaGenerica<ArbolGeneral<T>> lHijos = this.getHijos();
        
        lHijos.comenzar();
        if (!lHijos.esVacia()) {
        	(lHijos.proximo()).inOrden(l);
        }
        
        l.agregarFinal(this.getDato());
        while(!lHijos.fin()) {
            (lHijos.proximo()).inOrden(l);
        }   
    }
    
    
    public ListaEnlazadaGenerica<T> recorridoPorNiveles(){
        ListaEnlazadaGenerica<T> l = new ListaEnlazadaGenerica<T>();
        this.recorridoPorNiveles(l);
        return l;
    }
    
    private void recorridoPorNiveles(ListaGenerica<T> l) {
        ColaGenerica <ArbolGeneral<T>> cola = new ColaGenerica<ArbolGeneral<T>>();
        ArbolGeneral <T> arbol;
        cola.encolar(this);
        cola.encolar(null);
        while(!cola.esVacia()){
            arbol=cola.desencolar();
            if(arbol != null){
                l.agregarFinal(arbol.getDato());
                ListaGenerica<ArbolGeneral<T>> lHijos = arbol.getHijos();
                lHijos.comenzar();
                while (!lHijos.fin()) {
                	cola.encolar(lHijos.proximo());
                }
            }else if (!cola.esVacia()){
                System.out.println();
                cola.encolar(null);
            }
        }
    }
    
    
    
    public Boolean esAncestro(T a, T b) {
    	boolean esAncestro = false;
    	
    	ColaGenerica <ArbolGeneral<T>> cola = new ColaGenerica<ArbolGeneral<T>>();
        ArbolGeneral <T> arbol;
        
        ListaEnlazadaGenerica<T> descendientesA = new ListaEnlazadaGenerica<T>();
        
        cola.encolar(this);
        cola.encolar(null);
        
        while(!cola.esVacia()){
            arbol=cola.desencolar();
            if(arbol != null){
            	if (a == arbol.getDato()) {
            		descendientesA = arbol.posOrden(); // recupero los descendientes y vacio la cola
            		while (!cola.esVacia()) {
            			cola.desencolar();
            			
            		}
            	}else {
            		ListaGenerica<ArbolGeneral<T>> lHijos = arbol.getHijos();
                    lHijos.comenzar();
                    while (!lHijos.fin()) {
                    	cola.encolar(lHijos.proximo());
                    }
            	}
                
            }else if (!cola.esVacia()){
                cola.encolar(null);
            }
            
        }
    	
        if (!descendientesA.esVacia()) {
        	for (int i = 1; i < descendientesA.tamanio(); i++) {
        		if (descendientesA.elemento(i) == b) {
        			esAncestro = true;
        		}
        	}
        }
        
    	
    	return esAncestro;
    }
    
    public Boolean esAncestro2(T a, T b) {
    	return (!devolverSubArbol(b, devolverSubArbol(a, this)).esVacio());
    }
    
    private ArbolGeneral<T> devolverSubArbol(T dato, ArbolGeneral<T> ab){
    	ArbolGeneral<T> arbol = new ArbolGeneral<T>(null);
    	if (ab.getDato().equals(dato)) {
    		return ab;
    	}else {
    		if (ab.tieneHijos()) {
    			ListaGenerica<ArbolGeneral<T>> lHijos = ab.getHijos();
    			lHijos.comenzar();
    			while (!lHijos.fin()) {
    				devolverSubArbol(dato, lHijos.proximo());
    			}
    		}
    	}
    	return arbol;
    }
    
    
    /*public Boolean esAncestro2(T a, T b) { ESTE LO HICE CON EQUALS
        boolean esAncestro = false;

        ColaGenerica<ArbolGeneral<T>> cola = new ColaGenerica<ArbolGeneral<T>>();
        ArbolGeneral<T> arbol;

        ListaEnlazadaGenerica<T> descendientesA = new ListaEnlazadaGenerica<T>();

        cola.encolar(this);
        cola.encolar(null);

        while (!cola.esVacia()) {
            arbol = cola.desencolar();
            if (arbol != null) {
                if (arbol.getDato().equals(a)) { // Corregir la comparación de igualdad de objetos
                    descendientesA = arbol.posOrden(); // Recupero los descendientes y vacío la cola
                    while (!cola.esVacia()) {
                        cola.desencolar();
                    }
                }
                ListaGenerica<ArbolGeneral<T>> lHijos = arbol.getHijos();
                lHijos.comenzar();
                while (!lHijos.fin()) {
                    cola.encolar(lHijos.proximo());
                }
            } else if (!cola.esVacia()) {
                cola.encolar(null);
            }

        }
        descendientesA.comenzar();
        while (!descendientesA.fin()) {
        	System.out.println(descendientesA.proximo());
        }
        
        if (!descendientesA.esVacia()) {
        	for (int i = 1; i < descendientesA.tamanio(); i++) { // Corregir el índice de inicio del bucle
                if (descendientesA.elemento(i).equals(b)) { // Corregir la comparación de igualdad de objetos
                    esAncestro = true;
                }
            }
        }
        

        return esAncestro;
    }
    */
    
    
    
    
    
//-------------TODOS LOS IMPRIMIR---------------------
    
    public void printpreOrden(){
        System.out.println(this.getDato());
        ListaGenerica<ArbolGeneral<T>> Lhijos= this.getHijos();
        Lhijos.comenzar();
        while(!Lhijos.fin())
            Lhijos.proximo().printpreOrden();
    }
    
    public void printpostOrden(){
        ListaGenerica<ArbolGeneral<T>> Lhijos= this.getHijos();
        Lhijos.comenzar();
        while(!Lhijos.fin())
            Lhijos.proximo().printpostOrden(); 
        System.out.println(this.getDato());
    }
    public void printinOrden(){
        ListaGenerica<ArbolGeneral<T>> hijos;
        if(!this.esVacio()) {		
            hijos = this.getHijos();
            hijos.comenzar();
            if(this.tieneHijos()) {
                this.getHijos().proximo().printinOrden(); // Me quedo con el primer elemento (el HI)		
            }		
            System.out.println(this.getDato());
            while (!hijos.fin()) { // A este while ya entra con el 2do elemento de la lista
                hijos.proximo().printinOrden();
            }
        }	
    }
    
    
    public void printPorNiveles() {
        ColaGenerica <ArbolGeneral<T>> cola = new ColaGenerica<ArbolGeneral<T>>();
        ArbolGeneral <T> arbol;
        cola.encolar(this);
        cola.encolar(null);
        while(!cola.esVacia()){
            arbol=cola.desencolar();
            if(arbol != null){
            	System.out.println(arbol.getDato());
                ListaGenerica<ArbolGeneral<T>> lHijos = arbol.getHijos();
                lHijos.comenzar();
                while (!lHijos.fin()) {
                	cola.encolar(lHijos.proximo());
                }
            }else if (!cola.esVacia()){
                System.out.println();
                cola.encolar(null);
            }
        }
    }
    
}