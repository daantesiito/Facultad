package Parcial;
import PackElementos.*;

public class parcial {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    	//      	      2
	    //         /            \
	    //        7              -5
	    //       /  \           /
	    //      23   6         19
    	//     /    / \         \
	    //    -3   55  11        4 
    	//     			        /
    	//         	           18 
    	
	    ArbolBinario<Integer> padre = new ArbolBinario<Integer>(2);
	    
	    ArbolBinario<Integer> hijo1 = new ArbolBinario<Integer>(7);
	    ArbolBinario<Integer> hijo2 = new ArbolBinario<Integer>(-5);
	    
	    ArbolBinario<Integer> subhijo1 = new ArbolBinario<Integer>(23);
	    ArbolBinario<Integer> subhijo2 = new ArbolBinario<Integer>(6);
	    ArbolBinario<Integer> subhijo3 = new ArbolBinario<Integer>(19);
	    
	    ArbolBinario<Integer> subsubhijo1 = new ArbolBinario<Integer>(-3);
	    ArbolBinario<Integer> subsubhijo2 = new ArbolBinario<Integer>(55);
	    ArbolBinario<Integer> subsubhijo3 = new ArbolBinario<Integer>(11);
	    ArbolBinario<Integer> subsubhijo4 = new ArbolBinario<Integer>(4);
	    
	    ArbolBinario<Integer> subsubhijo5 = new ArbolBinario<Integer>(18);
	    
	    padre.agregarHijoIzquierdo(hijo1);
	    padre.agregarHijoDerecho(hijo2);
	    
	    hijo1.agregarHijoIzquierdo(subhijo1);
	    hijo1.agregarHijoDerecho(subhijo2);
	    
	    hijo2.agregarHijoIzquierdo(subhijo3);

	    subhijo1.agregarHijoIzquierdo(subsubhijo1);
	    
	    subhijo2.agregarHijoIzquierdo(subsubhijo2);
	    subhijo2.agregarHijoDerecho(subsubhijo3);
	    
	    subhijo3.agregarHijoDerecho(subsubhijo4);
	    
	    subsubhijo4.agregarHijoIzquierdo(subsubhijo5);
	    
	    //padre.printPorNiveles();
	    
	    ParcialArboles parci = new ParcialArboles(padre);
	    //ParcialArbolesCorrecion parci = new ParcialArbolesCorrecion(padre);
	    
	    int num = (7);
	    
	    boolean b = parci.isLeftTree(num);
	    
	    
	    System.out.println(b);
	    
	    
    }
}
