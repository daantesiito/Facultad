package ZParcial1;

import PackElementos.*;
import PackGrafos.*;

public class ejer12 {
	public static void main(String[] args) {
	/*1*/Ciudad2 ciudad = new Ciudad2("La Plata",1);
		Vertice<Ciudad2> LaPlata = new VerticeImplListAdy<Ciudad2>(ciudad);
	/*2*/Ciudad2 ciudad2 = new Ciudad2("Abasto",3);
		Vertice<Ciudad2> Abasto = new VerticeImplListAdy<Ciudad2>(ciudad2);
	/*3*/Ciudad2 ciudad3 = new Ciudad2("Cañuelas",2);
		Vertice<Ciudad2> Cañuelas = new VerticeImplListAdy<Ciudad2>(ciudad3);
	/*4*/Ciudad2 ciudad4 = new Ciudad2("Navarro",1);
		Vertice<Ciudad2> Navarro = new VerticeImplListAdy<Ciudad2>(ciudad4);
	/*5*/Ciudad2 ciudad5 = new Ciudad2("Quilmes",3);
		Vertice<Ciudad2> Quilmes = new VerticeImplListAdy<Ciudad2>(ciudad5);
	/*6*/Ciudad2 ciudad6 = new Ciudad2("Moreno",2);
		Vertice<Ciudad2> Moreno = new VerticeImplListAdy<Ciudad2>(ciudad6);
	/*7*/Ciudad2 ciudad7 = new Ciudad2("Carlos Keen",2);
		Vertice<Ciudad2> CarlosKeen = new VerticeImplListAdy<Ciudad2>(ciudad7);
	/*8*/Ciudad2 ciudad8 = new Ciudad2("Suipacha",3);
		Vertice<Ciudad2> Suipacha = new VerticeImplListAdy<Ciudad2>(ciudad8);
	/*9*/Ciudad2 ciudad9 = new Ciudad2("Pinamar",0);
		Vertice<Ciudad2> Pinamar = new VerticeImplListAdy<Ciudad2>(ciudad9);
	/*10*/Ciudad2 ciudad10 = new Ciudad2("Lobos",1);
		Vertice<Ciudad2> Lobos = new VerticeImplListAdy<Ciudad2>(ciudad10);
	/*11*/Ciudad2 ciudad11 = new Ciudad2("Saladillo",2);
		Vertice<Ciudad2> Saladillo = new VerticeImplListAdy<Ciudad2>(ciudad11);
		
		Grafo<Ciudad2> ciudades = new GrafoImplListAdy<Ciudad2>();
		
		ciudades.agregarVertice(LaPlata);
		ciudades.agregarVertice(Abasto);
		ciudades.agregarVertice(Cañuelas);
		ciudades.agregarVertice(Navarro);
		ciudades.agregarVertice(Quilmes);
		ciudades.agregarVertice(Moreno);
		ciudades.agregarVertice(CarlosKeen);
		ciudades.agregarVertice(Suipacha);
		ciudades.agregarVertice(Pinamar);
		ciudades.agregarVertice(Lobos);
		ciudades.agregarVertice(Saladillo);
		
		ciudades.conectar(LaPlata, Quilmes,2);
		ciudades.conectar(Quilmes,LaPlata,2);
		ciudades.conectar(Pinamar,LaPlata,2);
		ciudades.conectar(LaPlata,Pinamar,2);
		ciudades.conectar(LaPlata,Abasto,2);
		ciudades.conectar(Abasto,LaPlata,2);
		ciudades.conectar(Moreno,Quilmes,2);
		ciudades.conectar(Quilmes,Moreno,2);
		ciudades.conectar(Moreno,Abasto,3);
		ciudades.conectar(Abasto,Moreno,3);
		ciudades.conectar(Abasto,Cañuelas,2);
		ciudades.conectar(Cañuelas,Abasto,2);
		ciudades.conectar(Moreno,CarlosKeen,2);
		ciudades.conectar(CarlosKeen,Moreno,2);
		ciudades.conectar(CarlosKeen,Suipacha,2);
		ciudades.conectar(Suipacha,CarlosKeen,2);
		ciudades.conectar(Cañuelas,Navarro,2);
		ciudades.conectar(Navarro,Cañuelas,2);
		ciudades.conectar(Navarro,Suipacha,2);
		ciudades.conectar(Suipacha,Navarro,2);
		ciudades.conectar(Navarro,Saladillo,2);
		ciudades.conectar(Saladillo,Navarro,2);
		ciudades.conectar(Navarro,Lobos,4);
		ciudades.conectar(Lobos,Navarro,4);
		
		/*
		Parcial parcial = new Parcial();
		
		System.out.println(parcial.resolver(ciudades,"La Plata", "Navarro",2));
		*/
	}
}