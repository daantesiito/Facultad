package Practica4;

import PackElementos.*;

public class ProfundidadArbolGeneral {
    private ArbolGeneral<Integer> arbol;
    public ProfundidadArbolGeneral(ArbolGeneral<Integer> arbol){
        this.arbol=arbol;
    }
    
    public int sumaElementosProfundidad(int p) {
    	int suma=0;
    	if (p >= 0) {
            int nivelActual=0; 

            ColaGenerica <ArbolGeneral<Integer>> cola = new ColaGenerica<ArbolGeneral<Integer>>();
            ArbolGeneral <Integer> arbol;
            cola.encolar(this.arbol);
            cola.encolar(null);
            while (!cola.esVacia()){
                arbol=cola.desencolar();
                if(arbol != null){
                    if (nivelActual==p){
                        suma += arbol.getDato();
                        System.out.println("Dato: "+ arbol.getDato());
                    }
                    else {
                    	ListaGenerica<ArbolGeneral<Integer>> lHijos = arbol.getHijos();
                        lHijos.comenzar();
                        while (!lHijos.fin()) {
                            cola.encolar(lHijos.proximo());
                        }
                    }
                    
                }else if (!cola.esVacia()){
                	nivelActual++;
                    cola.encolar(null);
                }
            }
            if (nivelActual < p) suma = Integer.MAX_VALUE;
        }
        else {
            suma = Integer.MAX_VALUE;
        }
    	return suma;
    }
    
    
    
    public ListaGenerica<Integer> listaNoRepetidosNivel(int p) {
        ListaGenerica<Integer> lista = new ListaEnlazadaGenerica<Integer>();

        if (p >= 0){
            int nivelActual=0;
            ColaGenerica <ArbolGeneral<Integer>> cola = new ColaGenerica<ArbolGeneral<Integer>>();
            ArbolGeneral <Integer> arbol;
            cola.encolar(this.arbol);
            cola.encolar(null);
            while (!cola.esVacia()){
                arbol=cola.desencolar();
                if(arbol != null){
                    if (nivelActual==p){
                        if (!lista.incluye(arbol.getDato())) {
                            lista.agregarFinal(arbol.getDato());
                        }
                    }
                    else {
                        ListaGenerica<ArbolGeneral<Integer>> lHijos = arbol.getHijos();
                        lHijos.comenzar();
                        while (!lHijos.fin()) {
                            cola.encolar(lHijos.proximo());
                        }
                    }
                    
                }else if (!cola.esVacia()){
                    nivelActual++;
                    cola.encolar(null);
                }
            }
        }
        return lista;
    }
}