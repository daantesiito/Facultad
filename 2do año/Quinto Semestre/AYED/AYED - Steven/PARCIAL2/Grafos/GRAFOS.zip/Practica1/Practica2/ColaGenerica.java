/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Practica2;
//import Generica.*;
/**
 *
 * @author Esteban
 */
public class ColaGenerica<T> {
    
    private ListaGenerica<T> datos = new ListaEnlazadaGenerica<T>();

    public void encolar(T elem){
        datos.agregarFinal(elem);
    }
    
    public T desencolar(){
        T elemento = this.tope();
        datos.eliminarEn(1); //Elimino el primer elemento y despues lo retorno
        return elemento;
    }
    
    public T tope(){
        return datos.elemento(1);
    }
    
    public boolean esVacia(){
        return datos.esVacia();
    }
    
}
