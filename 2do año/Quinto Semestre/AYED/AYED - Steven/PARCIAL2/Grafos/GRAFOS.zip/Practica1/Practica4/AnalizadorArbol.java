package Practica4;

import PackElementos.*;

public class AnalizadorArbol {
    private ArbolGeneral<AreaEmpresa> arbol;
    
    public AnalizadorArbol(ArbolGeneral<AreaEmpresa> arbol){
        this.arbol=arbol;
    }
    
    public int devolverMaximoPromedio() {
    	int suma=0;
        //int nivelActual=0; 
        int max = -1;
        int cantNivel = 0;
        int prom = 0;
        ColaGenerica <ArbolGeneral<AreaEmpresa>> cola = new ColaGenerica<ArbolGeneral<AreaEmpresa>>();
        ArbolGeneral <AreaEmpresa> arbol;
        cola.encolar(this.arbol);
        cola.encolar(null);
        while (!cola.esVacia()){
            arbol=cola.desencolar();
            if(arbol != null){
            	suma += arbol.getDato().getTardanza();
            	cantNivel++;
            	
            	if (arbol.tieneHijos()) {
            		ListaGenerica<ArbolGeneral<AreaEmpresa>> lHijos = arbol.getHijos();
                	lHijos.comenzar();
                	while (!lHijos.fin()) {
                		cola.encolar(lHijos.proximo());
                    }	
            	}
            	//System.out.println("SUMA NIVEL " + nivelActual + " = " + suma);
            }else {
            	if (!cola.esVacia()){
            		cola.encolar(null);
            	}
            	if ((suma/cantNivel) > max)
            		max = suma/cantNivel;
            	suma = 0;
            	cantNivel = 0; 
            }
            	
            /*	
            	//suma = suma / cantNivel;
            	prom = suma / cantNivel;
            	if (prom > max)
            		max = prom;
            	//nivelActual++;
            	suma = 0;
            	cantNivel = 0; 
            }
            else {
            	prom = suma / cantNivel;
            	if (prom > max)
            		max = prom;
            }*/
        }
        return max;
    }
    
    
}