package practica1;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Esteban
 */
public class Profesor {
    
    private String nombre;
    private String apellido;
    private String mail;
    private String catedra;
    private String facultad;

    public Profesor(String nombre, String apellido, String mail, String catedra, String facultad) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.mail = mail;
        this.catedra = catedra;
        this.facultad = facultad;
    }
    
    

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public void setFacultad(String facultad) {
        this.facultad = facultad;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }
    
    public String getMail() {
        return mail;
    }

    public String getFacultad() {
        return facultad;
    }

    public void setCatedra(String catedra) {
        this.catedra = catedra;
    }

    public String getCatedra() {
        return catedra;
    }
    
    
    public String tusDatos() {
        return "Nombre: " + this.getNombre() + " " + this.getApellido() + ", mail: " + this.getMail() + ", catedra: " 
                + this.getCatedra() + ", facultad:" + this.getFacultad();
    }
    
    
}
