package Practica3V2;
//import PackElementos.*;
/**
 *
 * @author Esteban
 */
public class Punto2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        //          1
        //        /   \
        //       2     3
        //      / \   /
        //     4   5 6
        
        ArbolBinario<String> a1 = new ArbolBinario("1");
        ArbolBinario<String> a2 = new ArbolBinario("2");
        ArbolBinario<String> a3 = new ArbolBinario("3");
        ArbolBinario<String> a4 = new ArbolBinario("4");
        ArbolBinario<String> a5 = new ArbolBinario("5");
        ArbolBinario<String> a6 = new ArbolBinario("6");
        a1.agregarHijoIzquierdo(a2);
        a2.agregarHijoIzquierdo(a4);
        a2.agregarHijoDerecho(a5);
        a1.agregarHijoDerecho(a3);
        a3.agregarHijoIzquierdo(a6);
        
        a1.printPreorden();

        System.out.println("Su arbol tiene "+a1.contarNodos()+" nodos");
        System.out.println("Su arbol tiene "+a1.contarHojas()+" hojas");
        System.out.println("Su arbol tiene una altura de "+a1.altura());

        System.out.println("-------ENTRE NIVELES------");
        a1.entreNiveles(1,2);

        ArbolBinario<String> arbolEspejo = a1.espejo();
        System.out.println("----PREORDEN ESPEJO---");
        arbolEspejo.printPreorden();

        /*if(a1.esLleno()){
            System.out.println("ES LLENO");
        }else{
            System.out.println("NO ES LLENO");
        }*/
    }
    
}
