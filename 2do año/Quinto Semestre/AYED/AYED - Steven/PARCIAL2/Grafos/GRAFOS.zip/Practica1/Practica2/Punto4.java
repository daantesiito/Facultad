/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Practica2;

import java.util.Scanner;

/**
 *
 * @author Esteban
 */
public class Punto4 {

    /**
     * @param args the command line arguments
     */
    
    
    private static boolean esBalanceado(String expr) {
        ListaGenerica<Character> apertura = new ListaEnlazadaGenerica<Character>();
        apertura.agregarFinal('(');
        apertura.agregarFinal('[');
        apertura.agregarFinal('{');
        
        ListaGenerica<Character> cierre = new ListaEnlazadaGenerica<Character>();
        cierre.agregarFinal(')');
        cierre.agregarFinal(']');
        cierre.agregarFinal('}');
        
        PilaGenerica<Character> pila = new PilaGenerica<Character>();
        
        Character actual, elem;
        
        for (int i=0; i < expr.length(); i++){
            actual = expr.charAt(i);
            
            if (apertura.incluye(actual))
                pila.apilar(actual);
            else{
                elem = pila.desapilar();
                
                if (apertura.posicion(elem) != cierre.posicion(actual))
                    return false;
            }
            
        }
        
        
        if (!pila.esVacia())
            return false;

        return true;
    }
    
    
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner escaner = new Scanner(System.in) ;
        
        
        System.out.print("Ingrese un string: ");
        String s = escaner.nextLine();
        escaner.close();
        
        System.out.println("");
        if (esBalanceado(s))
            System.out.println("La expresión " + s + " está balanceada");
        else
            System.out.println("La expresión " + s + " NO está balanceada");
    }
    
}
