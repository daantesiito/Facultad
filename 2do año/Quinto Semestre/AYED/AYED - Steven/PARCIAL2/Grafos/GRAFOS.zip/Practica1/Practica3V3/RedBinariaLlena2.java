package Practica3V3;

import PackElementos.*;

public class RedBinariaLlena2 {
    private ArbolBinario<Integer> arbol;
    public RedBinariaLlena2(ArbolBinario<Integer> arbol){
        this.arbol=arbol;
    }
    public int retardoEnvio(){
        ColaGenerica<ArbolBinario<Integer>> cola= new ColaGenerica<ArbolBinario<Integer>>();
        int max=-1;
        int cant=0;
        int maxCant=-1;
        cola.encolar(this.arbol);
        cola.encolar(null);
        while(!cola.esVacia()){
            ArbolBinario<Integer> arbol=cola.desencolar();
            if (arbol!=null){
                if (arbol.tieneHijoIzquierdo()){//LE PONE AL HIJO IZQUIERDO LA SUMA DEL QUE ESTA PARADO + EL HIJO
                    arbol.getHijoIzquierdo().setDato(arbol.getHijoIzquierdo().getDato()+arbol.getDato());
                    cola.encolar(arbol.getHijoIzquierdo());//LO AGREGA A LA COLA
                }
                if (arbol.tieneHijoDerecho()){
                    arbol.getHijoDerecho().setDato(arbol.getHijoDerecho().getDato()+arbol.getDato());
                    cola.encolar(arbol.getHijoDerecho());
                }
                if (arbol.esHoja()){//SI NO TIENE HIJOS ES HOJA
                    cant++;
                    if (arbol.getDato()>=max){
                        max= arbol.getDato();//SUMO Y COMPARO CON EL MAXIMO, SI ES MAX ME GUARDO NRO DE HOJA
                        maxCant=cant;
                    }
                }
            } else if(!cola.esVacia()){
                cola.encolar(null);
            } 
        }
        System.out.println("La hoja con mayor retardo es la "+maxCant+", la cual tarda "+ max);
        return max;
    }
}