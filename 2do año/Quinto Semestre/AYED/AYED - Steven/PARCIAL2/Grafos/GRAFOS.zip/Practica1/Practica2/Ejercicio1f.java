/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Practica2;

/**
 *
 * @author Esteban
 */
public class Ejercicio1f {
    
    public static int secuencia(int n){
        //System.out.println(n);
        if (n != 1){
            if (n % 2 == 0){
                n = n/2;
            }
            else{
                n = 3*n+1;
            }
        }
        return n;
    }
    
    
    public ListaDeEnterosEnlazada calcularSucesion (int n) {
        ListaDeEnterosEnlazada l;
        if (n > 1){
            l = calcularSucesion(secuencia(n));
        }
        else{
            l = new ListaDeEnterosEnlazada();
        }
        l.agregarInicio(n);
        return l;
    }
    
    
    public static void main(String[] args) {
    	Ejercicio1f f = new Ejercicio1f();
        ListaDeEnterosEnlazada L = f. calcularSucesion(6);
        //Imprimir
        
        L.comenzar();
        while (!L.fin()) {
            System.out.println(L.proximo());
        }
        
    }
    
    
}
