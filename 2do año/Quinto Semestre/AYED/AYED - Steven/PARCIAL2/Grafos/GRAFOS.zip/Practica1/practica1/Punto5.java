package practica1;

import java.util.Scanner;
/**
 *
 * @author Esteban
 */
public class Punto5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner escaner = new Scanner(System.in) ;
        
        System.out.print("Ingrese la cantidad de elementos en el arreglo: ");
        int cant = escaner.nextInt();
        
        int []arreglo = new int[cant];
        
        for (int i = 0; i < cant; i++){
            System.out.print("Ingrese el elemento " + (i+1) + ": ");
            arreglo[i] = escaner.nextInt();
        }
        
        System.out.println("MAX: " + incisoA(arreglo)[0]);
        System.out.println("MIN: " + incisoA(arreglo)[1]);
        System.out.println("Promedio: " + incisoA(arreglo)[2]);
        
        
        
        
        
        Punto5IncisoB objetob = new Punto5IncisoB(9999, -1, 0);
        for (int i = 0; i < cant; i++){
            incisoB(arreglo[i], objetob);
        }
        objetob.setProm(objetob.getProm() / cant);
        
        System.out.println("Max: " + objetob.getMax());
        System.out.println("Min: " + objetob.getMin());
        System.out.println("Promedio: " + objetob.getProm());     
        
        
    }
    
    
    public static double[] incisoA (int[] arreglo){
        
        double[] array = new double[3];
        
        array[0] = -1;      // max
        array[1] = 9999;    // min
        array[2] = 0;
        
        for (int i = 0; i < arreglo.length; i++) {
            if (arreglo[i] > array[0]){
                array[0] = arreglo[i];  // calculo el max en array[0]
            }
            
            if(arreglo[i] < array[1]){
                array[1] = arreglo[i]; // calculo el min en array[1]
            }
            
            array[2] = array[2] + arreglo[i];   // calculo el total en array[2]
        }
        
        array[2] = array[2] / arreglo.length; // total/cantidad de elementos -> promedio
        
        return array;
    }
    
    
    public static void incisoB (int x, Punto5IncisoB objb){
        
        if (x > objb.getMax()){
            objb.setMax(x);
        }
        
        if (x < objb.getMin()){
            objb.setMin(x);
        }
        
        objb.setProm(objb.getProm() + x);
    }
    
}
