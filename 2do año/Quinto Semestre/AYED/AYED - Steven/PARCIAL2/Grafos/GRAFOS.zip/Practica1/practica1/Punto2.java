package practica1;
import java.util.Scanner;

/**
 *
 * @author Esteban
 */
public class Punto2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner escaner = new Scanner(System.in) ;
        
        System.out.print("Ingrese un numero: ");
        int n = escaner.nextInt();
        
        int []multiplos = new int[n];
        
        multiplos = calcularMultiplos(n);
        
        for (int i = 0; i < n; i++){
            System.out.println((i+1) + "- " + multiplos[i]);
        }
        
    }
    
    
    public static int[] calcularMultiplos (int n){
        int []vectorMultiplos = new int[n];
        
        for (int i = 0; i < n; i++){
            vectorMultiplos[i] = n * (i+1);
        }
        
        return vectorMultiplos;
    }
    
}
