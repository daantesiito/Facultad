package Practica4;

import PackElementos.*;

public class RecorridosAG {
	
	
	public ListaGenerica<Integer> numerosImparesMayoresQuePreOrden (ArbolGeneral<Integer> arbol, Integer n){
		ListaEnlazadaGenerica<Integer> l = new ListaEnlazadaGenerica<Integer>();
        this.numerosImpMayoresPreOrden(arbol, l, n);
        return l;
	}
	
	private void numerosImpMayoresPreOrden(ArbolGeneral<Integer> arbol, ListaGenerica<Integer> l, Integer n) {
        //raiz, hijos
		if ((arbol.getDato() % 2 != 0) & (arbol.getDato() > n)){
			l.agregarFinal(arbol.getDato());
		}
        ListaGenerica<ArbolGeneral<Integer>> lHijos = arbol.getHijos();
        lHijos.comenzar();
        while(!lHijos.fin()) {
        	numerosImpMayoresPreOrden(lHijos.proximo(), l, n);
        }
    }
	
	
	public ListaGenerica<Integer> numerosImparesMayoresQueInOrden (ArbolGeneral<Integer> arbol, Integer n){
		ListaEnlazadaGenerica<Integer> l = new ListaEnlazadaGenerica<Integer>();
        this.numerosImpMayoresInOrden(arbol, l, n);
        return l;
	}
	
	private void numerosImpMayoresInOrden(ArbolGeneral<Integer> arbol, ListaGenerica<Integer> l, Integer n) {
        //primer hio, raiz, otros hijos
		ListaGenerica<ArbolGeneral<Integer>> lHijos = arbol.getHijos();
	    
	    lHijos.comenzar();
	    if (!lHijos.esVacia()) {
	    	numerosImpMayoresInOrden(lHijos.proximo(), l, n);
	    }
	    
	    if ((arbol.getDato() % 2 != 0) & (arbol.getDato() > n)){
			l.agregarFinal(arbol.getDato());
		}
	    
	    while(!lHijos.fin()) {
	        numerosImpMayoresInOrden(lHijos.proximo(), l, n);
	    }
		
    }
	
	
	public ListaGenerica<Integer> numerosImparesMayoresQuePostOrden (ArbolGeneral<Integer> arbol, Integer n){
		ListaEnlazadaGenerica<Integer> l = new ListaEnlazadaGenerica<Integer>();
        this.numerosImpMayoresPostOrden(arbol, l, n);
        return l;
	}
	
	private void numerosImpMayoresPostOrden(ArbolGeneral<Integer> arbol, ListaGenerica<Integer> l, Integer n) {
        // hijos, raiz
        ListaGenerica<ArbolGeneral<Integer>> lHijos = arbol.getHijos();
        lHijos.comenzar();
        while(!lHijos.fin()) {
        	numerosImpMayoresPostOrden(lHijos.proximo(), l, n);
        }
        if ((arbol.getDato() % 2 != 0) & (arbol.getDato() > n)){
			l.agregarFinal(arbol.getDato());
		}
    }
	
	public ListaGenerica<Integer> numerosImparesMayoresQuePorNiveles (ArbolGeneral<Integer> arbol, Integer n){
		ListaEnlazadaGenerica<Integer> l = new ListaEnlazadaGenerica<Integer>();
        this.numerosImpMayoresPorNiveles(arbol, l, n);
        return l;
	}
	
	private void numerosImpMayoresPorNiveles(ArbolGeneral<Integer> arbol, ListaGenerica<Integer> l, Integer n) {
        ColaGenerica <ArbolGeneral<Integer>> cola = new ColaGenerica<ArbolGeneral<Integer>>();
    	cola.encolar(arbol);
    	cola.encolar(null);
    	while(!cola.esVacia()){
    	    arbol=cola.desencolar();
    	    if(arbol != null){
    	    	if ((arbol.getDato() % 2 != 0) & (arbol.getDato() > n)){
    				l.agregarFinal(arbol.getDato());
    			}
    	        ListaGenerica<ArbolGeneral<Integer>> lHijos = arbol.getHijos();
    	        lHijos.comenzar();
    	        while (!lHijos.fin()) {
    	        	cola.encolar(lHijos.proximo());
    	        }
    	    }else if (!cola.esVacia()){
    	    	l.agregarFinal(0);
    	        cola.encolar(null);
    	    }
    	}
    }
	  
}