/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Practica2;

import java.util.Scanner;

/**
 *
 * @author Esteban
 */
public class TestListaDeEnterosEnlazada {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner escaner = new Scanner(System.in) ;
        
        ListaDeEnterosEnlazada lista = new ListaDeEnterosEnlazada();
        lista.comenzar();
        
        System.out.print("Ingrese un numero: ");
        int num = escaner.nextInt();
        
        
        while (num != 0){
            lista.agregarFinal(num);
            System.out.print("Ingrese otro numero (<0> para terminar): ");
            num = escaner.nextInt();
        }
        
        
        for (int i = 0; i < lista.tamanio(); i++){
            System.out.println("Elemento de la lista en la posicion " + i + ": " + lista.elemento(i+1));
        }
        
        
        imprimirInverso(lista, lista.tamanio());
        
        
        secuencia(6);
        
    }
    
    
    public static void imprimirInverso(ListaDeEnteros l, int numero){
        if (numero > 0){
            System.out.println(l.elemento(numero));
            imprimirInverso(l, --numero);
        }
    }
    
    
    public static void secuencia(int n){
        System.out.println(n);
        if (n != 1){
            if (n % 2 == 0){
                n = n/2;
            }
            else{
                n = 3*n+1;
            }
            secuencia(n);
        }
    }
    
}
